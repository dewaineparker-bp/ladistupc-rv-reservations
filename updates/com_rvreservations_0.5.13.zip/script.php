<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;

class com_rvreservationsInstallerScript
{
    public function install(InstallerAdapter $parent): void
    {
        $this->ensureSchema();
    }

    public function update(InstallerAdapter $parent): void
    {
        $this->ensureSchema();
    }

    public function postflight(string $type, InstallerAdapter $parent): void
    {
        if (in_array($type, ['install', 'update', 'discover_install'], true)) {
            $this->ensureSchema();
            $this->ensureAuthoritativeSites();
            $this->applySuggestedMapPositions();
        }
    }


    private function ensureAuthoritativeSites(): void
    {
        // v0.5.2: Solidres room types are the authoritative RV-site inventory.
        // Earlier snapshots were derived from sr_rooms and could omit valid sites
        // such as 71. We only ADD missing sites here so administrator edits to
        // existing site records are preserved.
        $file = JPATH_ADMINISTRATOR . '/components/com_rvreservations/data/solidres_sites.json';
        $items = json_decode((string) @file_get_contents($file), true);
        if (!is_array($items) || !$items) { return; }

        $db = Factory::getContainer()->get('DatabaseDriver');
        foreach ($items as $x) {
            $number = trim((string) ($x['site_number'] ?? ''));
            if ($number === '') { continue; }

            $q = $db->getQuery(true)
                ->select('id')
                ->from($db->quoteName('#__rv_sites'))
                ->where('UPPER(' . $db->quoteName('site_number') . ') = UPPER(' . $db->quote($number) . ')');
            $db->setQuery($q);
            if ((int) $db->loadResult()) { continue; }

            $data = [
                'site_number' => $number,
                'title' => 'Site ' . $number,
                'description' => (string) ($x['description'] ?? ''),
                'amp_service' => (string) ($x['amp_service'] ?? ''),
                'location' => (string) ($x['location'] ?? ''),
                'rv_classes' => (string) ($x['rv_classes'] ?? ''),
                'lot_width' => $x['lot_width'] ?? null,
                'lot_length' => $x['lot_length'] ?? null,
                'foundation' => (string) ($x['foundation'] ?? ''),
                'shade_level' => (string) ($x['shade_level'] ?? ''),
                'handicap' => (int) ($x['handicap'] ?? 0),
                'notes' => (string) ($x['notes'] ?? ''),
                'source_room_type_id' => (int) ($x['source_room_type_id'] ?? 0),
                'state' => 1,
                'ordering' => (int) ($x['ordering'] ?? 0),
            ];

            $cols = array_keys($data);
            $vals = array_map(
                fn($v) => $v === null ? 'NULL' : $db->quote($v),
                array_values($data)
            );
            try {
                $q = $db->getQuery(true)
                    ->insert($db->quoteName('#__rv_sites'))
                    ->columns($db->quoteName($cols))
                    ->values(implode(',', $vals));
                $db->setQuery($q)->execute();
            } catch (\Throwable $e) {
                // Do not make the whole component update fail over one legacy row.
            }
        }
    }

    private function applySuggestedMapPositions(): void
    {
        // Starter positions are only applied to sites that are still unmapped.
        // Administrator adjustments are never overwritten by a component update.
        $file = JPATH_ADMINISTRATOR . '/components/com_rvreservations/data/split_premap.json';
        $items = json_decode((string) @file_get_contents($file), true);
        if (!is_array($items) || !$items) { return; }
        $db = Factory::getContainer()->get('DatabaseDriver');
        foreach ($items as $number => $pos) {
            $q = $db->getQuery(true)
                ->update($db->quoteName('#__rv_sites'))
                ->set($db->quoteName('map_region') . ' = ' . $db->quote((string) $pos['region']))
                ->set($db->quoteName('map_x') . ' = ' . $db->quote((float) $pos['x']))
                ->set($db->quoteName('map_y') . ' = ' . $db->quote((float) $pos['y']))
                ->set($db->quoteName('map_w') . ' = ' . $db->quote((float) $pos['w']))
                ->set($db->quoteName('map_h') . ' = ' . $db->quote((float) $pos['h']))
                ->set($db->quoteName('map_rotation') . ' = ' . $db->quote((float) ($pos['rotation'] ?? 0)))
                ->where('UPPER(' . $db->quoteName('site_number') . ') = UPPER(' . $db->quote($number) . ')')
                ->where($db->quoteName('map_x') . ' IS NULL');
            try { $db->setQuery($q)->execute(); } catch (\Throwable $e) {}
        }
    }

    private function ensureSchema(): void
    {
        $db = Factory::getContainer()->get('DatabaseDriver');

        // Self-healing base schema. This deliberately does not rely on an older
        // package having run its manifest SQL successfully.
        $statements = [
            <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_site_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `description` text NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL,
            <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_sites` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `site_type_id` int unsigned NULL,
  `site_number` varchar(50) NOT NULL,
  `title` varchar(150) NULL,
  `description` text NULL,
  `amp_service` varchar(20) NULL,
  `location` varchar(255) NULL,
  `rv_classes` varchar(255) NULL,
  `lot_width` smallint unsigned NULL,
  `lot_length` smallint unsigned NULL,
  `foundation` varchar(100) NULL,
  `shade_level` varchar(100) NULL,
  `handicap` tinyint NOT NULL DEFAULT 0,
  `notes` text NULL,
  `source_room_type_id` int unsigned NULL,
  `length_limit` smallint unsigned NULL,
  `map_key` varchar(100) NULL,
  `map_region` varchar(10) NULL,
  `map_rotation` decimal(7,3) NOT NULL DEFAULT 0,
  `map_x` decimal(7,4) NULL,
  `map_y` decimal(7,4) NULL,
  `map_w` decimal(7,4) NULL,
  `map_h` decimal(7,4) NULL,
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_sites_site_number` (`site_number`),
  KEY `idx_rv_sites_type` (`site_type_id`),
  KEY `idx_rv_sites_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL,
            <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `site_type_id` int unsigned NULL,
  `site_id` int unsigned NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `daily_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `priority` int NOT NULL DEFAULT 0,
  `state` tinyint NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_rv_rates_dates` (`date_from`, `date_to`),
  KEY `idx_rv_rates_mode` (`usage_mode`),
  KEY `idx_rv_rates_site` (`site_id`),
  KEY `idx_rv_rates_type` (`site_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL,
            <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_reservations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `confirmation_code` varchar(32) NULL,
  `customer_name` varchar(200) NULL,
  `customer_email` varchar(200) NULL,
  `customer_phone` varchar(50) NULL,
  `arrival` date NOT NULL,
  `departure` date NOT NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_status` varchar(30) NOT NULL DEFAULT 'unpaid',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_confirmation` (`confirmation_code`),
  KEY `idx_rv_res_dates` (`arrival`, `departure`),
  KEY `idx_rv_res_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL,
            <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_reservation_sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `site_id` int unsigned NOT NULL,
  `rate_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_res_site_unique` (`reservation_id`, `site_id`),
  KEY `idx_rv_reservation_id` (`reservation_id`),
  KEY `idx_rv_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL,
        ];


        $statements[] = <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NULL,
  `phone` varchar(50) NULL,
  `address1` varchar(255) NULL,
  `city` varchar(150) NULL,
  `state_code` varchar(50) NULL,
  `postal_code` varchar(30) NULL,
  `rv_class` varchar(100) NULL,
  `rv_length` smallint unsigned NULL,
  `notes` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rv_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL;
        $statements[] = <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_reservation_periods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `daily_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rv_period_reservation` (`reservation_id`),
  KEY `idx_rv_period_dates` (`date_from`, `date_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL;
        $statements[] = <<<'SQL'
CREATE TABLE IF NOT EXISTS `#__rv_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `gateway` varchar(50) NOT NULL DEFAULT 'authorize_net',
  `transaction_id` varchar(100) NULL,
  `transaction_type` varchar(30) NOT NULL DEFAULT 'charge',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `gateway_response` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rv_payment_reservation` (`reservation_id`),
  KEY `idx_rv_payment_transaction` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci
SQL;

        foreach ($statements as $sql) {
            $db->setQuery($db->replacePrefix($sql))->execute();
        }

        $table = $db->replacePrefix('#__rv_sites');
        $columns = $db->getTableColumns($table, false);

        // Upgrade older schemas without destroying data.
        $wanted = [
            'amp_service' => 'VARCHAR(20) NULL',
            'location' => 'VARCHAR(255) NULL AFTER `amp_service`',
            'rv_classes' => 'VARCHAR(255) NULL AFTER `location`',
            'lot_width' => 'SMALLINT UNSIGNED NULL AFTER `rv_classes`',
            'lot_length' => 'SMALLINT UNSIGNED NULL AFTER `lot_width`',
            'foundation' => 'VARCHAR(100) NULL AFTER `lot_length`',
            'shade_level' => 'VARCHAR(100) NULL AFTER `foundation`',
            'handicap' => 'TINYINT NOT NULL DEFAULT 0 AFTER `shade_level`',
            'notes' => 'TEXT NULL AFTER `handicap`',
            'source_room_type_id' => 'INT UNSIGNED NULL AFTER `notes`',
            'length_limit' => 'SMALLINT UNSIGNED NULL AFTER `source_room_type_id`',
            'max_slideouts' => 'TINYINT UNSIGNED NULL AFTER `length_limit`',
            'map_key' => 'VARCHAR(100) NULL AFTER `length_limit`',
            'map_region' => 'VARCHAR(10) NULL AFTER `map_key`',
            'map_rotation' => 'DECIMAL(7,3) NOT NULL DEFAULT 0 AFTER `map_region`',
            'map_x' => 'DECIMAL(7,4) NULL AFTER `map_rotation`',
            'map_y' => 'DECIMAL(7,4) NULL AFTER `map_x`',
            'map_w' => 'DECIMAL(7,4) NULL AFTER `map_y`',
            'map_h' => 'DECIMAL(7,4) NULL AFTER `map_w`',
            'site_status' => "VARCHAR(20) NOT NULL DEFAULT 'active' AFTER `map_h`",
            'state' => 'TINYINT NOT NULL DEFAULT 1 AFTER `site_status`',
            'ordering' => 'INT NOT NULL DEFAULT 0 AFTER `state`',
        ];

        foreach ($wanted as $name => $definition) {
            if (!isset($columns[$name])) {
                $query = 'ALTER TABLE ' . $db->quoteName($table)
                    . ' ADD ' . $db->quoteName($name) . ' ' . $definition;
                $db->setQuery($query)->execute();
            }
        }

        // Normalize site status without disturbing existing reservations or hand-edited map data.
        $db->setQuery(
            'UPDATE ' . $db->quoteName($table)
            . ' SET ' . $db->quoteName('site_status') . ' = CASE WHEN ' . $db->quoteName('state') . ' = 1 THEN ' . $db->quote('active') . ' ELSE ' . $db->quote('inactive') . ' END'
            . ' WHERE ' . $db->quoteName('site_status') . ' IS NULL OR ' . $db->quoteName('site_status') . ' = ' . $db->quote('')
        )->execute();

        // Site 28 is printed on the current campground map but was disabled in Solidres.
        $db->setQuery('SELECT id FROM ' . $db->quoteName($table) . ' WHERE UPPER(' . $db->quoteName('site_number') . ') = ' . $db->quote('28'));
        $site28 = (int) $db->loadResult();
        if (!$site28) {
            $q = $db->getQuery(true)->insert($db->quoteName('#__rv_sites'))
                ->columns($db->quoteName(['site_number','title','location','amp_service','lot_width','lot_length','rv_classes','site_status','state','ordering']))
                ->values(implode(',', [$db->quote('28'),$db->quote('Site 28'),$db->quote('B. Dees Loop'),$db->quote('50'),16,40,$db->quote('5th Wheel, Class A Motorhome, & Superclass Motorhome only'),$db->quote('inactive'),0,29]));
            $db->setQuery($q)->execute();
        } else {
            $db->setQuery('UPDATE ' . $db->quoteName($table) . ' SET ' . $db->quoteName('site_status') . ' = ' . $db->quote('inactive') . ', ' . $db->quoteName('state') . ' = 0 WHERE id = ' . $site28)->execute();
        }

        // Site 88 is printed on the map but has no Solidres reservation record, so keep it as map-only.
        $db->setQuery('SELECT id FROM ' . $db->quoteName($table) . ' WHERE UPPER(' . $db->quoteName('site_number') . ') = ' . $db->quote('88'));
        $site88 = (int) $db->loadResult();
        if (!$site88) {
            $q = $db->getQuery(true)->insert($db->quoteName('#__rv_sites'))
                ->columns($db->quoteName(['site_number','title','site_status','state','ordering']))
                ->values(implode(',', [$db->quote('88'),$db->quote('Site 88'),$db->quote('map_only'),0,88]));
            $db->setQuery($q)->execute();
        } else {
            $db->setQuery('UPDATE ' . $db->quoteName($table) . ' SET ' . $db->quoteName('site_status') . ' = ' . $db->quote('map_only') . ', ' . $db->quoteName('state') . ' = 0 WHERE id = ' . $site88)->execute();
        }

        // 1A exists in Solidres but is not printed on the current map. Remove only its map overlay;
        // the site record remains available for administrative review and can be re-mapped manually later.
        $db->setQuery('UPDATE ' . $db->quoteName($table)
            . ' SET ' . $db->quoteName('map_region') . ' = NULL, ' . $db->quoteName('map_x') . ' = NULL, ' . $db->quoteName('map_y') . ' = NULL, ' . $db->quoteName('map_w') . ' = NULL, ' . $db->quoteName('map_h') . ' = NULL, ' . $db->quoteName('map_rotation') . ' = 0'
            . ' WHERE UPPER(' . $db->quoteName('site_number') . ') = ' . $db->quote('1A'));


        $reservationTable = $db->replacePrefix('#__rv_reservations');
        $reservationColumns = $db->getTableColumns($reservationTable, false);
        if (!isset($reservationColumns['customer_id'])) {
            $db->setQuery(
                'ALTER TABLE ' . $db->quoteName($reservationTable)
                . ' ADD ' . $db->quoteName('customer_id') . ' BIGINT UNSIGNED NULL AFTER ' . $db->quoteName('confirmation_code')
            )->execute();
        }


        $customerTable = $db->replacePrefix('#__rv_customers');
        $customerColumns = $db->getTableColumns($customerTable, false);
        $customerWanted = [
            'rv_amp' => 'VARCHAR(10) NULL AFTER `rv_length`',
            'slideouts' => 'TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER `rv_amp`',
        ];
        foreach ($customerWanted as $name => $definition) {
            if (!isset($customerColumns[$name])) {
                $db->setQuery('ALTER TABLE ' . $db->quoteName($customerTable) . ' ADD ' . $db->quoteName($name) . ' ' . $definition)->execute();
            }
        }

        $reservationColumns = $db->getTableColumns($reservationTable, false);
        $reservationWanted = [
            'rv_length' => 'SMALLINT UNSIGNED NULL AFTER `departure`',
            'rv_amp' => 'VARCHAR(10) NULL AFTER `rv_length`',
            'rv_slideouts' => 'TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER `rv_amp`',
        ];
        foreach ($reservationWanted as $name => $definition) {
            if (!isset($reservationColumns[$name])) {
                $db->setQuery('ALTER TABLE ' . $db->quoteName($reservationTable) . ' ADD ' . $db->quoteName($name) . ' ' . $definition)->execute();
            }
        }

        // Ensure amp_service can contain values like "30/50" on old schemas.
        $columns = $db->getTableColumns($table, false);
        if (isset($columns['amp_service']) && stripos((string) $columns['amp_service']->Type, 'varchar') === false) {
            $query = 'ALTER TABLE ' . $db->quoteName($table)
                . ' MODIFY ' . $db->quoteName('amp_service') . ' VARCHAR(20) NULL';
            $db->setQuery($query)->execute();
        }
    }
}
