<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$hasSearch=!empty($this->search['arrival']) && !empty($this->search['departure']) && !empty($this->search['rv_length']) && !empty($this->search['amp']);
$area=in_array(($this->search['area']??''),['west','east'],true)?$this->search['area']:'';
$mapped=array_filter($this->mapSites,fn($s)=>$s['map_x']!==null && $s['map_y']!==null);
$unmappedAvailable=array_filter($this->sites,fn($s)=>$s['map_x']===null||$s['map_y']===null);
$selectedId=(int)($this->selectedSite['id']??0);

$siteArea=static fn(array $s): string => in_array(($s['map_region']??''),['west','east'],true)?$s['map_region']:'west';
$areaAvailable=['west'=>0,'east'=>0];
foreach($this->sites as $s){
    if(!empty($s['available']) && !empty($s['fits']) && $s['map_x']!==null && in_array(($s['map_region']??''),['west','east'],true)) $areaAvailable[$s['map_region']]++;
}
$regions=[
  'west'=>['label'=>'West Campground','image'=>'campground-map-west.jpg'],
  'east'=>['label'=>'East Campground','image'=>'campground-map-east.jpg'],
];

$queryBase='&arrival='.urlencode($this->search['arrival']??'')
    .'&departure='.urlencode($this->search['departure']??'')
    .'&rv_length='.(int)($this->search['rv_length']??0)
    .'&amp='.urlencode($this->search['amp']??'')
    .'&slideouts='.(int)($this->search['slideouts']??0);
?>
<div class="rv-wrap">
  <div class="rv-hero">
    <div class="rv-kicker">LA DISTRICT RV RESERVATIONS</div>
    <h1>Find your place at the campground</h1>
    <p>Enter your stay and RV details, choose a side of the campground, then select an available site from the map.</p>
  </div>

  <?php
    $rvStep = $this->confirmation ? 4 : ($selectedId ? 3 : ($hasSearch ? 2 : 1));
  ?>
  <div class="rv-progress" aria-label="Reservation progress">
    <?php foreach([[1,'Stay & RV'],[2,'Choose a site'],[3,'Your details'],[4,'Confirmation']] as [$stepNo,$stepLabel]): ?>
      <div class="rv-progress-step <?= $rvStep >= $stepNo ? 'is-active' : '' ?> <?= $rvStep === $stepNo ? 'is-current' : '' ?>">
        <span><?= $stepNo ?></span><strong><?= $stepLabel ?></strong>
      </div>
    <?php endforeach; ?>
  </div>

  <?php if($this->confirmation): ?>
    <section class="rv-confirmation">
      <div class="rv-confirm-icon">✓</div>
      <div class="rv-kicker">RESERVATION STARTED</div>
      <h2>Site <?= htmlspecialchars((string)$this->confirmation['site_number']) ?> is being held for you.</h2>
      <p class="rv-confirm-code">Confirmation <strong><?= htmlspecialchars((string)$this->confirmation['confirmation_code']) ?></strong></p>
      <div class="rv-summary-grid">
        <div><span>Arrival</span><strong><?= htmlspecialchars((string)$this->confirmation['arrival']) ?></strong></div>
        <div><span>Departure</span><strong><?= htmlspecialchars((string)$this->confirmation['departure']) ?></strong></div>
        <div><span>Total</span><strong>$<?= number_format((float)$this->confirmation['total'],2) ?></strong></div>
        <div><span>Payment</span><strong>Not collected yet</strong></div>
      </div>
      <p>Your reservation is currently <strong>pending</strong>. Pricing is now calculated; Authorize.net payment will be connected in the next phase.</p>
      <a class="rv-button rv-button-secondary" href="<?= Route::_('index.php?option=com_rvreservations') ?>">Start another reservation</a>
    </section>
  <?php else: ?>

  <?php if($selectedId && $hasSearch): ?>
    <section class="rv-checkout-card rv-detail-page">
      <div class="rv-kicker">YOUR SELECTED RV SITE</div>
      <h1>Site <?= htmlspecialchars((string)$this->selectedSite['site_number']) ?></h1>
      <div class="rv-summary-grid rv-selection-summary">
        <div><span>Arrival</span><strong><?= htmlspecialchars($this->search['arrival']) ?></strong></div>
        <div><span>Departure</span><strong><?= htmlspecialchars($this->search['departure']) ?></strong></div>
        <div><span>RV</span><strong><?= (int)$this->search['rv_length'] ?> ft • <?= htmlspecialchars($this->search['amp']) ?> AMP • <?= (int)$this->search['slideouts'] ?> slide<?= (int)$this->search['slideouts']===1?'':'s' ?></strong></div>
        <div><span>Site service</span><strong><?= htmlspecialchars((string)($this->selectedSite['amp_service'] ?: 'See site details')) ?></strong></div>
      </div>

      <?php if(empty($this->selectedSite['fits'])): ?>
        <div class="rv-notice rv-map-warning"><strong>This site does not match the RV information entered.</strong> <?= htmlspecialchars((string)($this->selectedSite['fit_reason']??'')) ?></div>
        <a class="rv-button rv-button-secondary" href="<?= Route::_('index.php?option=com_rvreservations'.$queryBase.'&area='.$area) ?>">Choose another site</a>
      <?php else: ?>
      <p class="rv-selected-site-note">Choose which nights the RV will be occupied. Unoccupied nights are charged at the stored rate.</p>

      <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=reservation.create') ?>" class="rv-customer-form">
        <input type="hidden" name="site_id" value="<?= $selectedId ?>">
        <input type="hidden" name="arrival" value="<?= htmlspecialchars($this->search['arrival'],ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="departure" value="<?= htmlspecialchars($this->search['departure'],ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="rv_length" value="<?= (int)$this->search['rv_length'] ?>">
        <input type="hidden" name="rv_amp" value="<?= htmlspecialchars($this->search['amp'],ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="rv_slideouts" value="<?= (int)$this->search['slideouts'] ?>">

        <div class="rv-field-wide rv-night-picker">
          <div class="rv-night-head">
            <div><h2>Occupied or stored?</h2><p>Select <strong>Occupied</strong> for each night someone will stay in the RV. Leave it off for <strong>Stored</strong>.</p></div>
            <div class="rv-price-total"><span>Reservation total</span><strong id="rv-price-total">$0.00</strong></div>
          </div>
          <div class="rv-night-grid">
          <?php $night=new DateTimeImmutable($this->search['arrival']); $end=new DateTimeImmutable($this->search['departure']); while($night < $end):
            $nightValue=$night->format('Y-m-d');
            $rates=$this->nightRates[$nightValue]??['occupied'=>0,'storage'=>0];
          ?>
            <label class="rv-night-option" data-occupied-rate="<?= number_format((float)$rates['occupied'],2,'.','') ?>" data-storage-rate="<?= number_format((float)$rates['storage'],2,'.','') ?>">
              <input type="checkbox" name="occupied_nights[]" value="<?= $nightValue ?>" checked>
              <span class="rv-night-date"><strong><?= $night->format('D, M j') ?></strong><small class="rv-night-mode">Occupied</small></span>
              <strong class="rv-night-price">$<?= number_format((float)$rates['occupied'],2) ?></strong>
            </label>
          <?php $night=$night->modify('+1 day'); endwhile; ?>
          </div>
          <div class="rv-night-actions"><button type="button" class="rv-text-button" data-night-action="all">Occupied all nights</button><button type="button" class="rv-text-button" data-night-action="none">Store all nights</button></div>
        </div>

        <div class="rv-field-wide rv-form-section-title"><span>Contact information</span><p>Tell us who is making this reservation.</p></div>
        <div class="rv-field"><label>Full name <em>*</em></label><input type="text" name="customer_name" required autocomplete="name" placeholder="First and last name"></div>
        <div class="rv-field"><label>Email <em>*</em></label><input type="email" name="customer_email" required autocomplete="email" placeholder="you@example.com"></div>
        <div class="rv-field"><label>Phone</label><input type="tel" name="customer_phone" autocomplete="tel" placeholder="(555) 555-5555"></div>
        <div class="rv-field"><label>RV type/class</label><select name="rv_class"><option value="">Choose RV type…</option><option>Class A Motorhome</option><option>Class B Motorvan</option><option>Class C Motorhome</option><option>Fifth-wheel</option><option>Bumper pull</option></select></div>
        <div class="rv-field-wide rv-form-section-title rv-form-section-title-spaced"><span>Mailing address</span><p>Used for the reservation record.</p></div>
        <div class="rv-field rv-field-wide"><label>Street address</label><input type="text" name="address1" autocomplete="street-address" placeholder="Street address"></div>
        <div class="rv-field"><label>City</label><input type="text" name="city" autocomplete="address-level2"></div>
        <div class="rv-field"><label>State</label><input type="text" name="state_code" autocomplete="address-level1"></div>
        <div class="rv-field"><label>ZIP</label><input type="text" name="postal_code" autocomplete="postal-code" inputmode="numeric"></div>
        <div class="rv-field rv-field-wide rv-notes-field"><label>Notes <small>Optional</small></label><textarea name="notes" rows="3" placeholder="Anything the RV office should know?"></textarea></div>
        <?= HTMLHelper::_('form.token') ?>
        <div class="rv-field-wide rv-detail-actions">
          <button class="rv-button" type="submit">Continue reservation</button>
          <a class="rv-button rv-button-secondary" href="<?= Route::_('index.php?option=com_rvreservations'.$queryBase.($area?'&area='.$area:'')) ?>">Choose a different site</a>
          <p class="rv-fineprint">The rate shown is based on the effective campground rates for each night. Payment is not collected yet.</p>
        </div>
      </form>
      <?php endif; ?>
    </section>

  <?php else: ?>
  <section class="rv-search-card">
    <div class="rv-section-heading">
      <div class="rv-kicker">STEP 1</div>
      <h2>Tell us about your stay and RV</h2>
      <p>We’ll use this information to hide sites that are booked or won’t comfortably fit your setup.</p>
    </div>
  <form class="rv-search rv-fit-search" action="<?= Route::_('index.php?option=com_rvreservations') ?>" method="get">
    <input type="hidden" name="option" value="com_rvreservations">
    <div class="rv-field"><label for="rv-arrival">Arrival</label><input id="rv-arrival" type="date" name="arrival" value="<?= htmlspecialchars($this->search['arrival'],ENT_QUOTES,'UTF-8') ?>" required></div>
    <div class="rv-field"><label for="rv-departure">Departure</label><input id="rv-departure" type="date" name="departure" value="<?= htmlspecialchars($this->search['departure'],ENT_QUOTES,'UTF-8') ?>" required></div>
    <div class="rv-field"><label for="rv-length">RV length (feet)</label><input id="rv-length" type="number" min="1" max="100" name="rv_length" value="<?= (int)($this->search['rv_length']??0) ?: '' ?>" required></div>
    <div class="rv-field"><label for="rv-amp">Electrical service needed</label><select id="rv-amp" name="amp" required><option value="">Choose…</option><option value="30" <?= ($this->search['amp']??'')==='30'?'selected':'' ?>>30 AMP</option><option value="50" <?= ($this->search['amp']??'')==='50'?'selected':'' ?>>50 AMP</option><option value="either" <?= ($this->search['amp']??'')==='either'?'selected':'' ?>>30 or 50 AMP (Either works)</option></select></div>
    <div class="rv-field"><label for="rv-slides">Number of slide-outs</label><input id="rv-slides" type="number" min="0" max="10" name="slideouts" value="<?= (int)($this->search['slideouts']??0) ?>" required></div>
    <button type="submit" class="rv-button rv-button-primary">Show compatible sites →</button>
  </form>
  </section>

  <?php if($this->siteCount===0): ?>
    <div class="rv-notice"><strong>No RV sites are loaded.</strong></div>
  <?php elseif($hasSearch): ?>
    <section class="rv-results">
      <?php if(!$area): ?>
        <div class="rv-side-choice">
          <div class="rv-kicker">STEP 2</div>
          <h2>Please select which side of the campground you wish to view first.</h2>
          <p><strong><?= count($this->sites) ?> sites</strong> match your dates and RV information. You can switch sides at any time without starting over.</p>
        </div>
        <div class="rv-area-grid rv-area-grid-compact" style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:14px;max-width:820px;margin:18px auto 0;align-items:start">
          <?php foreach($regions as $key=>$region): ?>
            <a class="rv-area-card rv-area-card-compact" style="display:flex;flex-direction:column;min-width:0;overflow:hidden" href="<?= Route::_('index.php?option=com_rvreservations'.$queryBase.'&area='.$key) ?>">
              <img style="display:block;width:100%;height:190px;object-fit:contain;background:#eef2f3;padding:8px" src="<?= htmlspecialchars(rtrim(Uri::root(),'/')) ?>/media/com_rvreservations/images/<?= $region['image'] ?>" alt="<?= htmlspecialchars($region['label']) ?>">
              <div class="rv-area-card-body"><h3><?= htmlspecialchars($region['label']) ?></h3><span class="rv-area-count"><?= (int)$areaAvailable[$key] ?> available</span></div>
            </a>
          <?php endforeach; ?>
        </div>
      <?php else: $region=$regions[$area]; $areaMapped=array_filter($mapped,fn($s)=>$siteArea($s)===$area); ?>
        <div class="rv-results-head">
          <div><div class="rv-kicker"><?= strtoupper($area) ?> CAMPGROUND</div><h2><?= htmlspecialchars($region['label']) ?></h2><p class="rv-result-sub"><?= count(array_filter($areaMapped,fn($s)=>!empty($s['available']) && !empty($s['fits']))) ?> compatible mapped sites available on this side.</p></div>
          <div class="rv-map-legend"><span><i class="rv-leg available"></i>Available</span><span><i class="rv-leg unavailable"></i>Unavailable for your search</span></div>
        </div>

        <div class="rv-area-switcher rv-area-switcher-prominent">
          <a class="rv-button rv-button-secondary" href="<?= Route::_('index.php?option=com_rvreservations'.$queryBase) ?>">← Choose campground side</a>
          <a class="rv-button rv-button-other-side" href="<?= Route::_('index.php?option=com_rvreservations'.$queryBase.'&area='.($area==='west'?'east':'west')) ?>">View <?= $area==='west'?'East':'West' ?> Campground →</a>
        </div>

        <div class="rv-map-toolbar" aria-label="Map controls">
          <button type="button" class="rv-map-tool" id="rv-map-expand">⛶ <span>Expand map</span></button>
          <div class="rv-map-zoom-group"><button type="button" class="rv-map-tool" id="rv-map-zoom-out">−</button><span id="rv-map-zoom-label">100%</span><button type="button" class="rv-map-tool" id="rv-map-zoom-in">+</button><button type="button" class="rv-map-tool" id="rv-map-zoom-reset">Reset</button></div>
        </div>

        <div class="rv-map-viewport rv-region-map-viewport" id="rv-map-viewport" data-area="<?= $area ?>" style="position:relative;width:100%;overflow:auto;background:#dfe3e6;max-height:82vh">
          <div class="rv-map-wrap rv-region-map-wrap" id="rv-map-wrap" style="position:relative;width:100%;max-width:1100px;margin:0 auto;background:#fff;overflow:hidden">
            <img src="<?= htmlspecialchars(rtrim(Uri::root(),'/')) ?>/media/com_rvreservations/images/<?= htmlspecialchars($region['image']) ?>" alt="<?= htmlspecialchars($region['label']) ?> map" class="rv-map-image" style="display:block;width:100%;height:auto">
            <?php foreach($areaMapped as $site):
              $selectable=!empty($site['available']) && !empty($site['fits']);
              $ampText=(string)($site['amp_service']?:'Service not listed');
              $lotText=(!empty($site['lot_width']) && !empty($site['lot_length'])) ? ((int)$site['lot_width'].' × '.(int)$site['lot_length'].' ft') : '';
              $details=array_filter(['Site '.(string)$site['site_number'],$ampText,$lotText]);
              $title=implode(' • ',$details);
              if(!$selectable && !empty($site['fit_reason'])) $title.=' — '.(string)$site['fit_reason'];
              elseif(!$selectable) $title.=' — unavailable for these dates';
              $bg=$selectable?'rgba(25,135,84,.08)':'rgba(70,74,78,.72)';
              $border=$selectable?'2px solid rgba(25,135,84,.95)':'1px solid rgba(70,75,80,.38)';
              $shadow=$selectable?'0 0 0 1px rgba(255,255,255,.78),0 0 10px rgba(25,135,84,.30)':'none';
              $critical='position:absolute;box-sizing:border-box;display:block;left:'.(float)$site['map_x'].'%;top:'.(float)$site['map_y'].'%;width:'.max(.20,(float)($site['map_w']?:2.5)).'%;height:'.max(.20,(float)($site['map_h']?:2.5)).'%;transform:rotate('.(float)($site['map_rotation']??0).'deg);transform-origin:center center;border:'.$border.';border-radius:2px;overflow:visible;z-index:'.($selectable?'3':'1').';background:'.$bg.';box-shadow:'.$shadow.';cursor:'.($selectable?'pointer':'not-allowed').';text-decoration:none;';
              if($selectable):
                $href=Route::_('index.php?option=com_rvreservations'.$queryBase.'&area='.$area.'&site_id='.(int)$site['id']); ?>
                <a class="rv-map-site is-available" href="<?= $href ?>" style="<?= htmlspecialchars($critical,ENT_QUOTES,'UTF-8') ?>" title="<?= htmlspecialchars($title,ENT_QUOTES,'UTF-8') ?>" aria-label="Reserve site <?= htmlspecialchars((string)$site['site_number'],ENT_QUOTES,'UTF-8') ?>"></a>
              <?php else: ?>
                <span class="rv-map-site is-unavailable" style="<?= htmlspecialchars($critical,ENT_QUOTES,'UTF-8') ?>" title="<?= htmlspecialchars($title,ENT_QUOTES,'UTF-8') ?>" aria-label="Site <?= htmlspecialchars((string)$site['site_number'],ENT_QUOTES,'UTF-8') ?> unavailable"></span>
              <?php endif; ?>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endif; ?>
    </section>
  <?php endif; ?>
  <?php endif; ?>
  <?php endif; ?>
</div>

<style>
/* v0.5.7 critical map UI — inline so host asset caching cannot hide availability */
.rv-region-map-wrap .rv-map-site.is-available:hover{background:rgba(25,135,84,.22)!important;box-shadow:0 0 0 2px rgba(255,255,255,.95),0 0 16px rgba(25,135,84,.75)!important;z-index:30!important}
.rv-region-map-wrap .rv-map-site.is-unavailable{filter:grayscale(.25)}
@media(max-width:640px){.rv-area-grid-compact{grid-template-columns:minmax(0,1fr) minmax(0,1fr)!important;gap:8px!important}.rv-area-card-compact img{height:120px!important;object-fit:contain!important}.rv-area-card-compact .rv-area-card-body{padding:8px!important}.rv-area-card-compact h3{font-size:.88rem!important}.rv-area-card-compact .rv-area-count{font-size:.66rem!important}}
</style>

<script>
document.addEventListener('DOMContentLoaded',()=>{
  const viewport=document.getElementById('rv-map-viewport'), map=document.getElementById('rv-map-wrap'), expand=document.getElementById('rv-map-expand'), zoomIn=document.getElementById('rv-map-zoom-in'), zoomOut=document.getElementById('rv-map-zoom-out'), zoomReset=document.getElementById('rv-map-zoom-reset'), zoomLabel=document.getElementById('rv-map-zoom-label');
  let zoom=1;
  function setZoom(next){if(!map)return;zoom=Math.max(1,Math.min(3,Math.round(next*10)/10));map.style.width=(zoom*100)+'%';if(zoomLabel)zoomLabel.textContent=Math.round(zoom*100)+'%';}
  if(zoomIn)zoomIn.addEventListener('click',()=>setZoom(zoom+.25));
  if(zoomOut)zoomOut.addEventListener('click',()=>setZoom(zoom-.25));
  if(zoomReset)zoomReset.addEventListener('click',()=>{setZoom(1);if(viewport){viewport.scrollTop=0;viewport.scrollLeft=0;}});
  if(expand&&viewport){expand.addEventListener('click',()=>{const on=viewport.classList.toggle('is-expanded');document.body.classList.toggle('rv-map-open',on);expand.querySelector('span').textContent=on?'Close expanded map':'Expand map';if(on)setZoom(Math.max(zoom,1.35));else setZoom(1);});}
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&viewport?.classList.contains('is-expanded'))expand?.click();});

  const money=n=>'$'+Number(n||0).toFixed(2);
  function recalc(){
    let total=0;
    document.querySelectorAll('.rv-night-option').forEach(row=>{
      const cb=row.querySelector('input[type="checkbox"]');
      if(!cb)return;
      const rate=Number(cb.checked?row.dataset.occupiedRate:row.dataset.storageRate);
      total+=rate;
      const mode=row.querySelector('.rv-night-mode'), price=row.querySelector('.rv-night-price');
      if(mode)mode.textContent=cb.checked?'Occupied':'Stored';
      if(price)price.textContent=money(rate);
    });
    const out=document.getElementById('rv-price-total'); if(out)out.textContent=money(total);
  }
  document.querySelectorAll('[data-night-action]').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('input[name="occupied_nights[]"]').forEach(cb=>cb.checked=btn.dataset.nightAction==='all');recalc();}));
  document.querySelectorAll('input[name="occupied_nights[]"]').forEach(cb=>cb.addEventListener('change',recalc));
  recalc();
});
</script>
