<?php
namespace LADistrict\Component\Rvreservations\Site\View\Reservation;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;

class HtmlView extends BaseHtmlView
{
    public array $search=[];
    public array $sites=[];
    public array $mapSites=[];
    public int $siteCount=0;
    public array $selectedSite=[];
    public array $confirmation=[];
    public array $nightRates=[];

    public function display($tpl=null): void
    {
        $this->search=$this->get('Search');
        $this->sites=$this->get('AvailableSites');
        $this->mapSites=$this->get('MapSites');
        $this->siteCount=$this->get('SiteCount');
        $this->selectedSite=$this->get('SelectedSite');
        $this->confirmation=$this->get('Confirmation');
        $this->nightRates=$this->get('NightRates');
        $document = Factory::getApplication()->getDocument();
        $document->getWebAssetManager()
          ->registerAndUseStyle('com_rvreservations.site','com_rvreservations/css/site.css');

        // Some shared hosts intermittently fail to serve component media assets.
        // Keep the normal Joomla asset registration, but inline the same stylesheet
        // as a fallback so the reservation UI is never rendered unstyled.
        $cssFile = JPATH_ROOT . '/media/com_rvreservations/css/site.css';
        if (is_file($cssFile)) {
            $css = file_get_contents($cssFile);
            if ($css !== false && $css !== '') {
                $document->addStyleDeclaration($css);
            }
        }
        parent::display($tpl);
    }
}
