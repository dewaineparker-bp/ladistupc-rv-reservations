<?php
namespace LADistrict\Component\Rvreservations\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;
use Joomla\Database\ParameterType;

class ReservationModel extends BaseDatabaseModel
{
    public function getSearch(): array
    {
        $input = Factory::getApplication()->getInput();
        return [
            'arrival'   => $input->getString('arrival', ''),
            'departure' => $input->getString('departure', ''),
            'area'      => strtolower($input->getCmd('area', '')),
            'rv_length' => max(0, $input->getInt('rv_length', 0)),
            'amp'       => $input->getCmd('amp', ''),
            'slideouts' => max(0, $input->getInt('slideouts', 0)),
        ];
    }

    public function getMapSites(): array
    {
        $search = $this->getSearch();
        if (!$this->validDates($search['arrival'], $search['departure'])) return [];

        $db=$this->getDatabase();
        $q=$db->getQuery(true)->select('s.*')->from($db->quoteName('#__rv_sites','s'))
          ->order('s.ordering ASC, s.site_number ASC');
        $db->setQuery($q);
        $sites=$db->loadAssocList() ?: [];

        $q=$db->getQuery(true)->select('DISTINCT rs.site_id')->from($db->quoteName('#__rv_reservation_sites','rs'))
          ->join('INNER',$db->quoteName('#__rv_reservations','r').' ON r.id=rs.reservation_id')
          ->where('r.status IN ('.$db->quote('pending').','.$db->quote('confirmed').')')
          ->where('r.arrival < :departure')->where('r.departure > :arrival');
        $q->bind(':arrival',$search['arrival'],ParameterType::STRING)->bind(':departure',$search['departure'],ParameterType::STRING);
        $db->setQuery($q);
        $booked=array_fill_keys(array_map('intval',$db->loadColumn() ?: []),true);

        foreach($sites as &$s) {
            $status=(string)($s['site_status'] ?? ($s['state'] ? 'active' : 'inactive'));
            $isActive=$status === 'active' && (int)$s['state'] === 1;
            $s['available']=$isActive && !isset($booked[(int)$s['id']]);
            if (!$isActive) {
                $fits=false;
                $reason=$status === 'map_only' ? 'Map reference only — not reservable' : 'Site is currently inactive';
            } else {
                [$fits,$reason]=$this->siteFits($s,$search);
            }
            $s['fits']=$fits;
            $s['fit_reason']=$reason;
        }
        unset($s);
        return $sites;
    }

    public function getAvailableSites(): array
    {
        return array_values(array_filter($this->getMapSites(), fn($s)=>!empty($s['available']) && !empty($s['fits'])));
    }

    public function getSelectedSite(): array
    {
        $id = Factory::getApplication()->getInput()->getInt('site_id');
        if (!$id) return [];
        $db=$this->getDatabase();
        $q=$db->getQuery(true)->select('*')->from($db->quoteName('#__rv_sites'))
          ->where($db->quoteName('id').' = '.(int)$id)->where($db->quoteName('state').' = 1')->where($db->quoteName('site_status').' = '.$db->quote('active'));
        $db->setQuery($q);
        $row=$db->loadAssoc() ?: [];
        if ($row) {
            [$fits,$reason]=$this->siteFits($row,$this->getSearch());
            $row['fits']=$fits;
            $row['fit_reason']=$reason;
        }
        return $row;
    }

    public function getNightRates(): array
    {
        $s=$this->getSearch();
        if(!$this->validDates($s['arrival'],$s['departure'])) return [];
        $db=$this->getDatabase();
        $q=$db->getQuery(true)
            ->select('usage_mode,date_from,date_to,daily_rate,priority')
            ->from($db->quoteName('#__rv_rates'))
            ->where('state=1')
            ->where('site_id IS NULL')
            ->where('site_type_id IS NULL')
            ->where('date_from < '.$db->quote($s['departure']))
            ->where('date_to >= '.$db->quote($s['arrival']))
            ->order('priority DESC, date_from DESC');
        $db->setQuery($q);
        $rates=$db->loadAssocList() ?: [];
        $out=[];
        $n=new \DateTimeImmutable($s['arrival']);
        $end=new \DateTimeImmutable($s['departure']);
        while($n<$end){
            $date=$n->format('Y-m-d');
            $out[$date]=['occupied'=>0.0,'storage'=>0.0];
            foreach(['occupied','storage'] as $mode){
                foreach($rates as $r){
                    if($r['usage_mode']!==$mode) continue;
                    if($date >= $r['date_from'] && $date <= $r['date_to']){
                        $out[$date][$mode]=(float)$r['daily_rate'];
                        break;
                    }
                }
            }
            $n=$n->modify('+1 day');
        }
        return $out;
    }

    public function getConfirmation(): array
    {
        $code = trim(Factory::getApplication()->getInput()->getString('confirmation', ''));
        if ($code === '') return [];
        $db=$this->getDatabase();
        $q=$db->getQuery(true)
          ->select('r.*, s.site_number, s.amp_service, s.location')
          ->from($db->quoteName('#__rv_reservations','r'))
          ->join('LEFT',$db->quoteName('#__rv_reservation_sites','rs').' ON rs.reservation_id=r.id')
          ->join('LEFT',$db->quoteName('#__rv_sites','s').' ON s.id=rs.site_id')
          ->where('r.confirmation_code = :code');
        $q->bind(':code',$code,ParameterType::STRING);
        $db->setQuery($q);
        return $db->loadAssoc() ?: [];
    }

    public function getSiteCount(): int
    {
        $db=$this->getDatabase();
        $q=$db->getQuery(true)->select('COUNT(*)')->from($db->quoteName('#__rv_sites'))->where('state=1')->where($db->quoteName('site_status').' = '.$db->quote('active'));
        $db->setQuery($q);
        return (int)$db->loadResult();
    }

    private function siteFits(array $site,array $search): array
    {
        $rvLength=(int)($search['rv_length']??0);
        $amp=(string)($search['amp']??'');
        $slides=(int)($search['slideouts']??0);

        $maxLength=(int)($site['length_limit'] ?: $site['lot_length'] ?: 0);
        if($rvLength>0 && $maxLength>0 && $rvLength>$maxLength){
            return [false,'RV is longer than this site'];
        }

        if(in_array($amp,['30','50','either'],true)){
            $service=strtoupper((string)($site['amp_service']??''));
            $has30=(bool)preg_match('/(^|[^0-9])30([^0-9]|$)/',$service);
            $has50=(bool)preg_match('/(^|[^0-9])50([^0-9]|$)/',$service);
            if($amp==='30' && !$has30){
                return [false,'30 AMP service is not listed for this site'];
            }
            if($amp==='50' && !$has50){
                return [false,'50 AMP service is not listed for this site'];
            }
            if($amp==='either' && !$has30 && !$has50){
                return [false,'30 or 50 AMP service is not listed for this site'];
            }
        }

        $maxSlides=$site['max_slideouts'] ?? null;
        if($maxSlides!==null && $maxSlides!=='' && $slides>(int)$maxSlides){
            return [false,'Too many slide-outs for this site'];
        }
        $text=strtolower(strip_tags((string)($site['notes']??'').' '.(string)($site['description']??'')));
        if($slides>0 && preg_match('/\b(no|zero)\s+slides?\b|\bwithout\s+slides?\b/',$text)){
            return [false,'This site does not allow slide-outs'];
        }
        return [true,''];
    }

    private function validDates(string $arrival,string $departure): bool
    {
        if(!$arrival||!$departure)return false;
        $a=\DateTimeImmutable::createFromFormat('!Y-m-d',$arrival);
        $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$departure);
        return $a&&$d&&$d>$a;
    }
}
