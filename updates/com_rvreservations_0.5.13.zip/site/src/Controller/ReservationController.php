<?php
namespace LADistrict\Component\Rvreservations\Site\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\Database\ParameterType;

class ReservationController extends BaseController
{
    public function create(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app = Factory::getApplication();
        $i = $app->getInput();

        $siteId = $i->post->getInt('site_id');
        $arrival = $i->post->getString('arrival');
        $departure = $i->post->getString('departure');
        $rvLength = max(0, $i->post->getInt('rv_length'));
        $rvAmp = $i->post->getCmd('rv_amp', '');
        $rvSlideouts = max(0, $i->post->getInt('rv_slideouts'));
        $occupiedNights = array_values(array_unique(array_filter((array) $i->post->get('occupied_nights', [], 'array'), fn($v) => is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $v))));
        $name = trim($i->post->getString('customer_name'));
        $email = trim($i->post->getString('customer_email'));
        $phone = trim($i->post->getString('customer_phone'));

        if (!$siteId || !$this->validDates($arrival, $departure) || $name === '' || $email === '') {
            $app->enqueueMessage('Please complete the required reservation fields.', 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations&arrival='.urlencode($arrival).'&departure='.urlencode($departure), false));
            return;
        }

        $db = Factory::getContainer()->get('DatabaseDriver');
        try {
            $db->transactionStart();

            $q = $db->getQuery(true)
                ->select('COUNT(*)')
                ->from($db->quoteName('#__rv_reservation_sites', 'rs'))
                ->join('INNER', $db->quoteName('#__rv_reservations', 'r') . ' ON r.id = rs.reservation_id')
                ->where('rs.site_id = :site_id')
                ->where('r.status IN (' . $db->quote('pending') . ',' . $db->quote('confirmed') . ')')
                ->where('r.arrival < :departure')
                ->where('r.departure > :arrival');
            $q->bind(':site_id', $siteId, ParameterType::INTEGER)
              ->bind(':arrival', $arrival, ParameterType::STRING)
              ->bind(':departure', $departure, ParameterType::STRING);
            $db->setQuery($q);
            if ((int)$db->loadResult() > 0) {
                throw new \RuntimeException('That site was just reserved by someone else. Please choose another available site.');
            }

            $customer = (object)[
                'name'=>$name,'email'=>$email,'phone'=>$phone,
                'address1'=>trim($i->post->getString('address1')),
                'city'=>trim($i->post->getString('city')),
                'state_code'=>trim($i->post->getString('state_code')),
                'postal_code'=>trim($i->post->getString('postal_code')),
                'rv_class'=>trim($i->post->getString('rv_class')),
                'rv_length'=>$rvLength ?: null,
                'rv_amp'=>$rvAmp ?: null,
                'slideouts'=>$rvSlideouts,
                'notes'=>$i->post->getString('notes'),
            ];
            $db->insertObject('#__rv_customers', $customer);
            $customerId = (int)$db->insertid();

            $occupiedLookup=array_fill_keys($occupiedNights,true);
            $night=new \DateTimeImmutable($arrival);
            $end=new \DateTimeImmutable($departure);
            $nightRows=[];
            $total=0.0;
            $ordering=0;
            while($night < $end){
                $date=$night->format('Y-m-d');
                $next=$night->modify('+1 day');
                $mode=isset($occupiedLookup[$date])?'occupied':'storage';
                $rate=$this->rateForDate($db,$date,$mode);
                $total += $rate;
                $nightRows[]=[
                    'date_from'=>$date,'date_to'=>$next->format('Y-m-d'),
                    'usage_mode'=>$mode,'daily_rate'=>$rate,'period_total'=>$rate,'ordering'=>$ordering++
                ];
                $night=$next;
            }

            $code = strtoupper(substr(bin2hex(random_bytes(8)), 0, 10));
            $reservation = (object)[
                'confirmation_code'=>$code,'customer_id'=>$customerId,
                'customer_name'=>$name,'customer_email'=>$email,'customer_phone'=>$phone,
                'arrival'=>$arrival,'departure'=>$departure,
                'rv_length'=>$rvLength ?: null,'rv_amp'=>$rvAmp ?: null,'rv_slideouts'=>$rvSlideouts,
                'usage_mode'=>$this->summaryMode($arrival, $departure, $occupiedNights),
                'status'=>'pending','subtotal'=>$total,'total'=>$total,'payment_status'=>'unpaid'
            ];
            $db->insertObject('#__rv_reservations', $reservation);
            $reservationId = (int)$db->insertid();

            $link=(object)['reservation_id'=>$reservationId,'site_id'=>$siteId,'rate_total'=>$total];
            $db->insertObject('#__rv_reservation_sites',$link);

            foreach($nightRows as $row){
                $row['reservation_id']=$reservationId;
                $periodRecord=(object)$row;
                $db->insertObject('#__rv_reservation_periods',$periodRecord);
            }

            $db->transactionCommit();
            $this->setRedirect(Route::_('index.php?option=com_rvreservations&confirmation='.urlencode($code), false));
        } catch (\Throwable $e) {
            try { $db->transactionRollback(); } catch (\Throwable $ignore) {}
            $app->enqueueMessage($e->getMessage(), 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations&arrival='.urlencode($arrival).'&departure='.urlencode($departure), false));
        }
    }

    private function rateForDate($db,string $date,string $mode): float
    {
        $q=$db->getQuery(true)
            ->select('daily_rate')
            ->from($db->quoteName('#__rv_rates'))
            ->where('state=1')
            ->where('site_id IS NULL')
            ->where('site_type_id IS NULL')
            ->where('usage_mode='.$db->quote($mode))
            ->where('date_from <= '.$db->quote($date))
            ->where('date_to >= '.$db->quote($date))
            ->order('priority DESC, date_from DESC');
        $db->setQuery($q,0,1);
        return (float)($db->loadResult() ?: 0);
    }

    private function summaryMode(string $arrival, string $departure, array $occupiedNights): string
    {
        $nights=(new \DateTimeImmutable($arrival))->diff(new \DateTimeImmutable($departure))->days;
        $occupied=count($occupiedNights);
        return $occupied===0 ? 'storage' : ($occupied >= $nights ? 'occupied' : 'mixed');
    }

    private function validDates(string $arrival, string $departure): bool
    {
        if (!$arrival || !$departure) return false;
        $a=\DateTimeImmutable::createFromFormat('!Y-m-d',$arrival);
        $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$departure);
        return $a && $d && $d > $a;
    }
}
