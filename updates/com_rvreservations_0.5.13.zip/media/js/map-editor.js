document.addEventListener('DOMContentLoaded', () => {
  const stage = document.querySelector('[data-rv-map-editor]');
  if (!stage) return;

  const select = document.getElementById('rv-map-site');
  const box = document.getElementById('rv-map-current');
  const handle = box.querySelector('.rv-map-resize-handle');
  const x = document.getElementById('rv-map-x');
  const y = document.getElementById('rv-map-y');
  const w = document.getElementById('rv-map-w');
  const h = document.getElementById('rv-map-h');
  const rotation = document.getElementById('rv-map-rotation-value');
  const ws = document.getElementById('rv-map-width');
  const hs = document.getElementById('rv-map-height');
  const rotationSlider = document.getElementById('rv-map-rotation');
  const rotationLabel = document.getElementById('rv-map-rotation-label');
  const rotateLeft = document.getElementById('rv-rotate-left');
  const rotateRight = document.getElementById('rv-rotate-right');
  const label = box.querySelector('span');
  const viewport = document.getElementById('rv-admin-map-viewport');
  const expandBtn = document.getElementById('rv-admin-map-expand');
  const zoomIn = document.getElementById('rv-admin-map-zoom-in');
  const zoomOut = document.getElementById('rv-admin-map-zoom-out');
  const zoomReset = document.getElementById('rv-admin-map-reset');
  const zoomLabel = document.getElementById('rv-admin-map-zoom-label');
  const editingLabel = document.getElementById('rv-admin-map-editing');
  const zoomLevels = [100,125,150,175,200,250,300,350,400];
  let zoomIndex = 0;
  const data = JSON.parse(stage.dataset.sites || '{}');
  if (window.RVMapRenderer) window.RVMapRenderer.renderFromDataset(stage, {mode:'admin'});
  let dragMode = null;
  let start = null;

  function clamp(v,min,max){ return Math.max(min,Math.min(max,v)); }
  function vals(){
    return {
      x: parseFloat(x.value) || 0,
      y: parseFloat(y.value) || 0,
      w: parseFloat(w.value) || 1,
      h: parseFloat(h.value) || 1,
      rotation: parseFloat(rotation.value) || 0
    };
  }
  function setZoom(index){
    zoomIndex = clamp(index,0,zoomLevels.length-1);
    const z = zoomLevels[zoomIndex];
    stage.style.width = z + '%';
    stage.style.minWidth = z + '%';
    if (zoomLabel) zoomLabel.textContent = z + '%';
  }
  function render(){
    const v=vals();
    box.style.left=v.x+'%';
    box.style.top=v.y+'%';
    box.style.width=v.w+'%';
    box.style.height=v.h+'%';
    box.style.transform='rotate('+v.rotation+'deg)';
    box.hidden=!select.value;
    const siteLabel=select.options[select.selectedIndex]?.text?.replace(' ✓','')||'';
    label.textContent=siteLabel;
    if(editingLabel) editingLabel.textContent=siteLabel?('Editing site '+siteLabel):'Choose a site to edit';
    ws.value=v.w;
    hs.value=v.h;
    rotationSlider.value=v.rotation;
    rotationLabel.textContent=Math.round(v.rotation)+'°';
  }
  function load(){
    const d=data[select.value]||{};
    x.value=d.x ?? 45;
    y.value=d.y ?? 45;
    w.value=d.w ?? 1.5;
    h.value=d.h ?? 1.5;
    rotation.value=d.rotation ?? 0;
    render();
    if(select.value && !data[select.value]) box.scrollIntoView({behavior:'smooth',block:'center'});
  }
  function point(e){
    const r=stage.getBoundingClientRect();
    return {x:(e.clientX-r.left)/r.width*100,y:(e.clientY-r.top)/r.height*100};
  }

  select.addEventListener('change',load);
  stage.addEventListener('click',e=>{
    if(!select.value || e.target.closest('.rv-admin-map-box')) return;
    const p=point(e),v=vals();
    x.value=clamp(p.x-v.w/2,0,100-v.w).toFixed(4);
    y.value=clamp(p.y-v.h/2,0,100-v.h).toFixed(4);
    render();
  });
  box.addEventListener('pointerdown',e=>{
    if(!select.value) return;
    e.preventDefault();e.stopPropagation();
    dragMode=e.target===handle?'resize':'move';
    start={p:point(e),v:vals()};
    box.setPointerCapture(e.pointerId);
  });
  box.addEventListener('pointermove',e=>{
    if(!dragMode||!start)return;
    const p=point(e),dx=p.x-start.p.x,dy=p.y-start.p.y;
    if(dragMode==='move'){
      x.value=clamp(start.v.x+dx,0,100-start.v.w).toFixed(4);
      y.value=clamp(start.v.y+dy,0,100-start.v.h).toFixed(4);
    }else{
      // Rotation is visual only; resize remains axis based for predictable editing.
      w.value=clamp(start.v.w+dx,.05,100-start.v.x).toFixed(4);
      h.value=clamp(start.v.h+dy,.05,100-start.v.y).toFixed(4);
    }
    render();
  });
  ['pointerup','pointercancel'].forEach(name=>box.addEventListener(name,()=>{dragMode=null;start=null;}));

  ws.addEventListener('input',()=>{w.value=ws.value;render();});
  hs.addEventListener('input',()=>{h.value=hs.value;render();});
  rotationSlider.addEventListener('input',()=>{rotation.value=rotationSlider.value;render();});
  rotateLeft.addEventListener('click',()=>{rotation.value=clamp((parseFloat(rotation.value)||0)-5,-180,180);render();});
  rotateRight.addEventListener('click',()=>{rotation.value=clamp((parseFloat(rotation.value)||0)+5,-180,180);render();});

  if(expandBtn&&viewport){
    expandBtn.addEventListener('click',()=>{
      const open=viewport.classList.toggle('is-expanded');
      document.body.classList.toggle('rv-admin-map-expanded',open);
      expandBtn.textContent=open?'Close Expanded Map':'Expand Map';
      if(open && zoomIndex<2)setZoom(2);
    });
  }
  if(zoomIn) zoomIn.addEventListener('click',()=>setZoom(zoomIndex+1));
  if(zoomOut) zoomOut.addEventListener('click',()=>setZoom(zoomIndex-1));
  if(zoomReset) zoomReset.addEventListener('click',()=>{setZoom(0);if(viewport){viewport.scrollTop=0;viewport.scrollLeft=0;}});
  document.addEventListener('keydown',e=>{
    if(e.key==='Escape'&&viewport?.classList.contains('is-expanded')){
      viewport.classList.remove('is-expanded');
      document.body.classList.remove('rv-admin-map-expanded');
      if(expandBtn)expandBtn.textContent='Expand Map';
    }
  });

  setZoom(0);
  load();
});
