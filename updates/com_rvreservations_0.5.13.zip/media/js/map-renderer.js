(function () {
  'use strict';

  function num(value, fallback) {
    var n = parseFloat(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function makeOverlay(site, mode) {
    var available = site.available !== false && String(site.available) !== '0';
    var clickable = mode === 'public' && available && site.href;
    var el = document.createElement(clickable ? 'a' : 'span');
    el.className = mode === 'admin' ? 'rv-admin-map-saved' : 'rv-map-site ' + (available ? 'is-available' : 'is-unavailable');
    el.dataset.siteId = String(site.id || '');
    el.dataset.siteNumber = String(site.label || site.site_number || '');
    el.style.left = num(site.x, 0) + '%';
    el.style.top = num(site.y, 0) + '%';
    el.style.width = num(site.w, 2.5) + '%';
    el.style.height = num(site.h, 2.5) + '%';
    el.style.setProperty('--rv-rotation', num(site.rotation, 0) + 'deg');
    el.style.transform = 'rotate(' + num(site.rotation, 0) + 'deg)';

    var label = String(site.label || site.site_number || '');
    el.title = 'Site ' + label + (mode === 'public' && !available ? ' — unavailable' : '');
    el.setAttribute('aria-label', mode === 'public' ? (available ? 'Reserve site ' : 'Site unavailable ') + label : 'Mapped site ' + label);

    if (clickable) {
      el.href = site.href;
      var span = document.createElement('span');
      span.textContent = label;
      el.appendChild(span);
    } else if (mode === 'public') {
      var span2 = document.createElement('span');
      span2.textContent = label;
      el.appendChild(span2);
    }

    return el;
  }

  function render(stage, sites, options) {
    if (!stage) return [];
    options = options || {};
    var mode = options.mode || stage.dataset.mapMode || 'public';
    stage.querySelectorAll('[data-rv-rendered-site="1"]').forEach(function (node) { node.remove(); });
    var created = [];
    (sites || []).forEach(function (site) {
      if (site.x === null || site.y === null || typeof site.x === 'undefined' || typeof site.y === 'undefined') return;
      var el = makeOverlay(site, mode);
      el.dataset.rvRenderedSite = '1';
      var before = stage.querySelector('#rv-map-current');
      if (before) stage.insertBefore(el, before); else stage.appendChild(el);
      created.push(el);
    });
    return created;
  }

  function renderFromDataset(stage, options) {
    if (!stage) return [];
    var sites = [];
    try { sites = JSON.parse(stage.dataset.mapSites || '[]'); } catch (e) { console.error('RV map data could not be read', e); }
    return render(stage, sites, options);
  }

  window.RVMapRenderer = { render: render, renderFromDataset: renderFromDataset };
})();
