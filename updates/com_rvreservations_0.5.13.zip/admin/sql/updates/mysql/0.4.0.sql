CREATE TABLE IF NOT EXISTS `#__rv_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NULL,
  `phone` varchar(50) NULL,
  `address1` varchar(255) NULL,
  `city` varchar(150) NULL,
  `state_code` varchar(50) NULL,
  `postal_code` varchar(30) NULL,
  `rv_class` varchar(100) NULL,
  `rv_length` smallint unsigned NULL,
  `notes` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rv_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_reservation_periods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `daily_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rv_period_reservation` (`reservation_id`),
  KEY `idx_rv_period_dates` (`date_from`, `date_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `gateway` varchar(50) NOT NULL DEFAULT 'authorize_net',
  `transaction_id` varchar(100) NULL,
  `transaction_type` varchar(30) NOT NULL DEFAULT 'charge',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `gateway_response` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rv_payment_reservation` (`reservation_id`),
  KEY `idx_rv_payment_transaction` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
