ALTER TABLE `#__rv_sites` ADD COLUMN IF NOT EXISTS `site_status` varchar(20) NOT NULL DEFAULT 'active' AFTER `map_h`;
UPDATE `#__rv_sites` SET `site_status` = CASE WHEN `state` = 1 THEN 'active' ELSE 'inactive' END WHERE `site_status` IS NULL OR `site_status` = '';
