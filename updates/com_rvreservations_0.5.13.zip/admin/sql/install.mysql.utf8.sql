CREATE TABLE IF NOT EXISTS `#__rv_site_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `description` text NULL,
  `site_status` varchar(20) NOT NULL DEFAULT 'active',
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_sites` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `site_type_id` int unsigned NULL,
  `site_number` varchar(50) NOT NULL,
  `title` varchar(150) NULL,
  `description` text NULL,
  `amp_service` varchar(20) NULL,
  `location` varchar(255) NULL,
  `rv_classes` varchar(255) NULL,
  `lot_width` smallint unsigned NULL,
  `lot_length` smallint unsigned NULL,
  `foundation` varchar(100) NULL,
  `shade_level` varchar(100) NULL,
  `handicap` tinyint NOT NULL DEFAULT 0,
  `notes` text NULL,
  `source_room_type_id` int unsigned NULL,
  `length_limit` smallint unsigned NULL,
  `max_slideouts` tinyint unsigned NULL,
  `map_key` varchar(100) NULL,
  `map_region` varchar(10) NULL,
  `map_rotation` decimal(7,3) NOT NULL DEFAULT 0,
  `map_x` decimal(7,4) NULL,
  `map_y` decimal(7,4) NULL,
  `map_w` decimal(7,4) NULL,
  `map_h` decimal(7,4) NULL,
  `site_status` varchar(20) NOT NULL DEFAULT 'active',
  `state` tinyint NOT NULL DEFAULT 1,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_sites_site_number` (`site_number`),
  KEY `idx_rv_sites_type` (`site_type_id`),
  KEY `idx_rv_sites_state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `site_type_id` int unsigned NULL,
  `site_id` int unsigned NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `daily_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `priority` int NOT NULL DEFAULT 0,
  `state` tinyint NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_rv_rates_dates` (`date_from`, `date_to`),
  KEY `idx_rv_rates_mode` (`usage_mode`),
  KEY `idx_rv_rates_site` (`site_id`),
  KEY `idx_rv_rates_type` (`site_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_reservations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `confirmation_code` varchar(32) NULL,
  `customer_id` bigint unsigned NULL,
  `customer_name` varchar(200) NULL,
  `customer_email` varchar(200) NULL,
  `customer_phone` varchar(50) NULL,
  `arrival` date NOT NULL,
  `departure` date NOT NULL,
  `rv_length` smallint unsigned NULL,
  `rv_amp` varchar(10) NULL,
  `rv_slideouts` tinyint unsigned NOT NULL DEFAULT 0,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_status` varchar(30) NOT NULL DEFAULT 'unpaid',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_confirmation` (`confirmation_code`),
  KEY `idx_rv_res_dates` (`arrival`, `departure`),
  KEY `idx_rv_res_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_reservation_sites` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `site_id` int unsigned NOT NULL,
  `rate_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rv_res_site_unique` (`reservation_id`, `site_id`),
  KEY `idx_rv_reservation_id` (`reservation_id`),
  KEY `idx_rv_site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS `#__rv_customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NULL,
  `phone` varchar(50) NULL,
  `address1` varchar(255) NULL,
  `city` varchar(150) NULL,
  `state_code` varchar(50) NULL,
  `postal_code` varchar(30) NULL,
  `rv_class` varchar(100) NULL,
  `rv_length` smallint unsigned NULL,
  `rv_amp` varchar(10) NULL,
  `slideouts` tinyint unsigned NOT NULL DEFAULT 0,
  `notes` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rv_customer_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_reservation_periods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `usage_mode` varchar(20) NOT NULL DEFAULT 'occupied',
  `daily_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `period_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `ordering` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `idx_rv_period_reservation` (`reservation_id`),
  KEY `idx_rv_period_dates` (`date_from`, `date_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__rv_payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reservation_id` bigint unsigned NOT NULL,
  `gateway` varchar(50) NOT NULL DEFAULT 'authorize_net',
  `transaction_id` varchar(100) NULL,
  `transaction_type` varchar(30) NOT NULL DEFAULT 'charge',
  `amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `gateway_response` text NULL,
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rv_payment_reservation` (`reservation_id`),
  KEY `idx_rv_payment_transaction` (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 DEFAULT COLLATE=utf8mb4_unicode_ci;
