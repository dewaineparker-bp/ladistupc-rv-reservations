<?php
namespace LADistrict\Component\Rvreservations\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

class SiteController extends BaseController
{
    public function save(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app = Factory::getApplication();
        $i = $app->getInput();
        $id = $i->post->getInt('id');
        $number = trim($i->post->getString('site_number'));
        if ($number === '') {
            $app->enqueueMessage('Site number is required.', 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations', false)); return;
        }
        $db = Factory::getContainer()->get('DatabaseDriver');
        $status = strtolower($i->post->getCmd('site_status', 'active'));
        if (!in_array($status, ['active','inactive','map_only'], true)) $status = 'active';
        $data = [
          'site_number'=>$number,
          'title'=>trim($i->post->getString('title')),
          'location'=>trim($i->post->getString('location')),
          'rv_classes'=>trim($i->post->getString('rv_classes')),
          'amp_service'=>trim($i->post->getString('amp_service')),
          'lot_width'=>$i->post->getInt('lot_width') ?: null,
          'lot_length'=>$i->post->getInt('lot_length') ?: null,
          'max_slideouts'=>$i->post->getString('max_slideouts','') === '' ? null : max(0,$i->post->getInt('max_slideouts')),
          'foundation'=>trim($i->post->getString('foundation')),
          'shade_level'=>trim($i->post->getString('shade_level')),
          'handicap'=>$i->post->getInt('handicap') ? 1 : 0,
          'notes'=>$i->post->getString('notes'),
          'description'=>$i->post->getString('description'),
          'site_status'=>$status,
          'state'=>$status === 'active' ? 1 : 0,
          'ordering'=>$i->post->getInt('ordering'),
        ];
        if ($id) {
            $sets=[];
            foreach($data as $k=>$v) $sets[]=$db->quoteName($k) . ' = ' . ($v===null ? 'NULL' : $db->quote($v));
            $q=$db->getQuery(true)->update($db->quoteName('#__rv_sites'))->set($sets)->where($db->quoteName('id').' = '.(int)$id);
        } else {
            $cols=array_keys($data); $vals=array_map(fn($v)=>$v===null?'NULL':$db->quote($v), array_values($data));
            $q=$db->getQuery(true)->insert($db->quoteName('#__rv_sites'))->columns($db->quoteName($cols))->values(implode(',',$vals));
        }
        try { $db->setQuery($q)->execute(); $app->enqueueMessage('RV site saved.'); }
        catch (\Throwable $e) { $app->enqueueMessage('Could not save site: '.$e->getMessage(), 'error'); }
        $this->setRedirect(Route::_('index.php?option=com_rvreservations', false));
    }

    public function toggle(): void
    {
        Session::checkToken('get') or jexit(Text::_('JINVALID_TOKEN'));
        $app=Factory::getApplication(); $id=$app->getInput()->getInt('id'); $state=$app->getInput()->getInt('state')?1:0;
        $db=Factory::getContainer()->get('DatabaseDriver');
        $q=$db->getQuery(true)->update($db->quoteName('#__rv_sites'))->set([$db->quoteName('state').' = '.(int)$state, $db->quoteName('site_status').' = '.$db->quote($state ? 'active' : 'inactive')])->where($db->quoteName('id').' = '.(int)$id);
        $db->setQuery($q)->execute();
        $app->enqueueMessage($state ? 'Site enabled.' : 'Site disabled.');
        $this->setRedirect(Route::_('index.php?option=com_rvreservations', false));
    }

    public function importSnapshot(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app=Factory::getApplication();
        $file=JPATH_ADMINISTRATOR . '/components/com_rvreservations/data/solidres_sites.json';
        $items=json_decode((string) @file_get_contents($file), true);
        if (!is_array($items)) {
            $app->enqueueMessage('Solidres snapshot could not be read.', 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations', false)); return;
        }
        $db=Factory::getContainer()->get('DatabaseDriver'); $added=0; $updated=0;
        foreach($items as $x) {
            $number=trim((string)($x['site_number']??'')); if($number==='') continue;
            $db->setQuery($db->getQuery(true)->select('id')->from($db->quoteName('#__rv_sites'))->where('UPPER('.$db->quoteName('site_number').') = UPPER('.$db->quote($number).')'));
            $id=(int)$db->loadResult();
            $data=[
              'site_number'=>$number,'title'=>'Site '.$number,'description'=>(string)($x['description']??''),'amp_service'=>(string)($x['amp_service']??''),
              'location'=>(string)($x['location']??''),'rv_classes'=>(string)($x['rv_classes']??''),'lot_width'=>$x['lot_width']??null,'lot_length'=>$x['lot_length']??null,
              'foundation'=>(string)($x['foundation']??''),'shade_level'=>(string)($x['shade_level']??''),'handicap'=>(int)($x['handicap']??0),'notes'=>(string)($x['notes']??''),
              'source_room_type_id'=>(int)($x['source_room_type_id']??0),'state'=>1,'ordering'=>(int)($x['ordering']??0)
            ];
            if($id){
                $sets=[]; foreach($data as $k=>$v) $sets[]=$db->quoteName($k).' = '.($v===null?'NULL':$db->quote($v));
                $q=$db->getQuery(true)->update($db->quoteName('#__rv_sites'))->set($sets)->where($db->quoteName('id').' = '.$id); $updated++;
            } else {
                $cols=array_keys($data); $vals=array_map(fn($v)=>$v===null?'NULL':$db->quote($v),array_values($data));
                $q=$db->getQuery(true)->insert($db->quoteName('#__rv_sites'))->columns($db->quoteName($cols))->values(implode(',',$vals)); $added++;
            }
            $db->setQuery($q)->execute();
        }
        $app->enqueueMessage("Solidres site snapshot imported: $added added, $updated updated. Authoritative Solidres room-type inventory imported; duplicate labels were collapsed to one site.");
        $this->setRedirect(Route::_('index.php?option=com_rvreservations', false));
    }

    public function saveMap(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app = Factory::getApplication();
        $i = $app->getInput();
        $id = $i->post->getInt('site_id');
        if (!$id) {
            $app->enqueueMessage('Choose an RV site first.', 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations#map-editor', false)); return;
        }
        $vals = [];
        foreach (['map_x','map_y','map_w','map_h'] as $name) {
            $v = (float) $i->post->getString($name, '0');
            $vals[$name] = max(0.0, min(100.0, $v));
        }
        $region = strtolower($i->post->getCmd('map_region', 'west'));
        if (!in_array($region, ['west','east'], true)) $region = 'west';
        $rotation = max(-180.0, min(180.0, (float) $i->post->getString('map_rotation', '0')));
        if ($vals['map_w'] <= 0 || $vals['map_h'] <= 0) {
            $app->enqueueMessage('Map width and height must be greater than zero.', 'error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations&map_area='.$region.'#map-editor', false)); return;
        }
        $db = Factory::getContainer()->get('DatabaseDriver');
        $sets=[];
        foreach($vals as $k=>$v) $sets[]=$db->quoteName($k).' = '.$db->quote(number_format($v,4,'.',''));
        $sets[]=$db->quoteName('map_region').' = '.$db->quote($region);
        $sets[]=$db->quoteName('map_rotation').' = '.$db->quote(number_format($rotation,3,'.',''));
        $q=$db->getQuery(true)->update($db->quoteName('#__rv_sites'))->set($sets)->where($db->quoteName('id').' = '.(int)$id);
        $db->setQuery($q)->execute();
        $app->enqueueMessage('Map position saved.');
        $this->setRedirect(Route::_('index.php?option=com_rvreservations&map_area='.$region.'&map_site='.(int)$id.'#map-editor', false));
    }

    public function clearMap(): void
    {
        Session::checkToken('get') or jexit(Text::_('JINVALID_TOKEN'));
        $app=Factory::getApplication(); $id=$app->getInput()->getInt('id');
        $db=Factory::getContainer()->get('DatabaseDriver');
        $q=$db->getQuery(true)->update($db->quoteName('#__rv_sites'))
            ->set([$db->quoteName('map_region').' = NULL',$db->quoteName('map_x').' = NULL',$db->quoteName('map_y').' = NULL',$db->quoteName('map_w').' = NULL',$db->quoteName('map_h').' = NULL',$db->quoteName('map_rotation').' = 0'])
            ->where($db->quoteName('id').' = '.(int)$id);
        $db->setQuery($q)->execute();
        $app->enqueueMessage('Map position cleared.');
        $this->setRedirect(Route::_('index.php?option=com_rvreservations#map-editor', false));
    }

}
