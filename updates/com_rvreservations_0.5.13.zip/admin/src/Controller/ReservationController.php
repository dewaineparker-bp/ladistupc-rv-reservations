<?php
namespace LADistrict\Component\Rvreservations\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;
use Joomla\Database\ParameterType;

class ReservationController extends BaseController
{
    public function save(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app=Factory::getApplication();
        $i=$app->getInput();
        $id=$i->post->getInt('id');
        $siteId=$i->post->getInt('site_id');
        $arrival=$i->post->getString('arrival');
        $departure=$i->post->getString('departure');
        $occupiedNights=array_values(array_unique(array_filter((array)$i->post->get('occupied_nights',[],'array'),fn($v)=>is_string($v)&&preg_match('/^\d{4}-\d{2}-\d{2}$/',$v))));
        $mode=$this->summaryMode($arrival,$departure,$occupiedNights);
        $status=$i->post->getCmd('status','pending');
        if(!in_array($status,['pending','confirmed','cancelled'],true))$status='pending';

        if(!$id||!$siteId||!$this->validDates($arrival,$departure)){
            $app->enqueueMessage('Reservation, site, arrival and departure are required.','error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations',false)); return;
        }

        $db=Factory::getContainer()->get('DatabaseDriver');
        try{
            $db->transactionStart();
            $q=$db->getQuery(true)->select('COUNT(*)')
              ->from($db->quoteName('#__rv_reservation_sites','rs'))
              ->join('INNER',$db->quoteName('#__rv_reservations','r').' ON r.id=rs.reservation_id')
              ->where('rs.site_id=:site_id')
              ->where('r.id <> :id')
              ->where('r.status IN ('.$db->quote('pending').','.$db->quote('confirmed').')')
              ->where('r.arrival < :departure')->where('r.departure > :arrival');
            $q->bind(':site_id',$siteId,ParameterType::INTEGER)
              ->bind(':id',$id,ParameterType::INTEGER)
              ->bind(':arrival',$arrival,ParameterType::STRING)
              ->bind(':departure',$departure,ParameterType::STRING);
            $db->setQuery($q);
            if((int)$db->loadResult()>0)throw new \RuntimeException('The selected site is already reserved for part of those dates.');

            $occupiedLookup=array_fill_keys($occupiedNights,true);
            $night=new \DateTimeImmutable($arrival); $end=new \DateTimeImmutable($departure); $ordering=0; $total=0.0; $rows=[];
            while($night < $end){
                $date=$night->format('Y-m-d'); $next=$night->modify('+1 day');
                $use=isset($occupiedLookup[$date])?'occupied':'storage';
                $rate=$this->rateForDate($db,$date,$use);
                $total+=$rate;
                $rows[]=['date_from'=>$date,'date_to'=>$next->format('Y-m-d'),'usage_mode'=>$use,'daily_rate'=>$rate,'period_total'=>$rate,'ordering'=>$ordering++];
                $night=$next;
            }

            $q=$db->getQuery(true)->update($db->quoteName('#__rv_reservations'))
              ->set([
                $db->quoteName('arrival').'='.$db->quote($arrival),
                $db->quoteName('departure').'='.$db->quote($departure),
                $db->quoteName('usage_mode').'='.$db->quote($mode),
                $db->quoteName('status').'='.$db->quote($status),
                $db->quoteName('subtotal').'='.$db->quote(number_format($total,2,'.','')),
                $db->quoteName('total').'='.$db->quote(number_format($total,2,'.','')),
                $db->quoteName('modified').'='.$db->quote(date('Y-m-d H:i:s')),
              ])->where('id='.(int)$id);
            $db->setQuery($q)->execute();

            $db->setQuery($db->getQuery(true)->delete($db->quoteName('#__rv_reservation_sites'))->where('reservation_id='.(int)$id))->execute();
            $reservationSite=(object)['reservation_id'=>$id,'site_id'=>$siteId,'rate_total'=>$total];
            $db->insertObject('#__rv_reservation_sites',$reservationSite);

            $db->setQuery($db->getQuery(true)->delete($db->quoteName('#__rv_reservation_periods'))->where('reservation_id='.(int)$id))->execute();
            foreach($rows as $row){
                $row['reservation_id']=$id;
                $periodRecord=(object)$row;
                $db->insertObject('#__rv_reservation_periods',$periodRecord);
            }
            $db->transactionCommit();
            $app->enqueueMessage('Reservation updated and pricing recalculated.');
        }catch(\Throwable $e){
            try{$db->transactionRollback();}catch(\Throwable $ignore){}
            $app->enqueueMessage($e->getMessage(),'error');
        }
        $this->setRedirect(Route::_('index.php?option=com_rvreservations#reservations',false));
    }

    private function rateForDate($db,string $date,string $mode): float
    {
        $q=$db->getQuery(true)->select('daily_rate')->from($db->quoteName('#__rv_rates'))
            ->where('state=1')->where('site_id IS NULL')->where('site_type_id IS NULL')
            ->where('usage_mode='.$db->quote($mode))
            ->where('date_from <= '.$db->quote($date))->where('date_to >= '.$db->quote($date))
            ->order('priority DESC, date_from DESC');
        $db->setQuery($q,0,1);
        return (float)($db->loadResult() ?: 0);
    }

    private function summaryMode(string $arrival,string $departure,array $occupiedNights): string
    {
        $nights=(new \DateTimeImmutable($arrival))->diff(new \DateTimeImmutable($departure))->days;
        $occupied=count($occupiedNights);
        return $occupied===0?'storage':($occupied >= $nights?'occupied':'mixed');
    }

    private function validDates(string $arrival,string $departure): bool
    {
        $a=\DateTimeImmutable::createFromFormat('!Y-m-d',$arrival);
        $d=\DateTimeImmutable::createFromFormat('!Y-m-d',$departure);
        return $a&&$d&&$d>$a;
    }
}
