<?php
namespace LADistrict\Component\Rvreservations\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\BaseController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

class RateController extends BaseController
{
    public function save(): void
    {
        Session::checkToken() or jexit(Text::_('JINVALID_TOKEN'));
        $app=Factory::getApplication();
        $i=$app->getInput();
        $effective=$i->post->getString('effective_date');
        $occupied=(float)$i->post->getString('occupied_rate','0');
        $storage=(float)$i->post->getString('storage_rate','0');

        $date=\DateTimeImmutable::createFromFormat('!Y-m-d',$effective);
        if(!$date || $occupied<0 || $storage<0){
            $app->enqueueMessage('Enter a valid effective date and non-negative rates.','error');
            $this->setRedirect(Route::_('index.php?option=com_rvreservations#pricing',false));
            return;
        }

        $db=Factory::getContainer()->get('DatabaseDriver');
        try{
            $db->transactionStart();
            $dayBefore=$date->modify('-1 day')->format('Y-m-d');

            foreach(['occupied'=>$occupied,'storage'=>$storage] as $mode=>$rate){
                // Close any earlier open range that crosses this effective date.
                $q=$db->getQuery(true)->update($db->quoteName('#__rv_rates'))
                    ->set($db->quoteName('date_to').'='.$db->quote($dayBefore))
                    ->where('state=1')
                    ->where('site_id IS NULL')->where('site_type_id IS NULL')
                    ->where('usage_mode='.$db->quote($mode))
                    ->where('date_from < '.$db->quote($effective))
                    ->where('date_to >= '.$db->quote($effective));
                $db->setQuery($q)->execute();

                // End this new range the day before the next future effective rate, if one exists.
                $q=$db->getQuery(true)->select('MIN(date_from)')->from($db->quoteName('#__rv_rates'))
                    ->where('state=1')->where('site_id IS NULL')->where('site_type_id IS NULL')
                    ->where('usage_mode='.$db->quote($mode))->where('date_from > '.$db->quote($effective));
                $db->setQuery($q);
                $nextDate=(string)($db->loadResult() ?: '');
                $newEnd=$nextDate ? (new \DateTimeImmutable($nextDate))->modify('-1 day')->format('Y-m-d') : '9999-12-31';

                // Replace same-date global rate if it already exists.
                $q=$db->getQuery(true)->select('id')->from($db->quoteName('#__rv_rates'))
                    ->where('site_id IS NULL')->where('site_type_id IS NULL')
                    ->where('usage_mode='.$db->quote($mode))
                    ->where('date_from='.$db->quote($effective));
                $db->setQuery($q);
                $id=(int)$db->loadResult();

                if($id){
                    $q=$db->getQuery(true)->update($db->quoteName('#__rv_rates'))
                        ->set([
                            $db->quoteName('date_to').'='.$db->quote($newEnd),
                            $db->quoteName('daily_rate').'='.$db->quote(number_format($rate,2,'.','')),
                            $db->quoteName('state').'=1'
                        ])->where('id='.$id);
                    $db->setQuery($q)->execute();
                } else {
                    $rateRecord=(object)[
                        'site_type_id'=>null,'site_id'=>null,'usage_mode'=>$mode,
                        'date_from'=>$effective,'date_to'=>$newEnd,
                        'daily_rate'=>$rate,'priority'=>0,'state'=>1
                    ];
                    $db->insertObject('#__rv_rates',$rateRecord);
                }
            }
            $db->transactionCommit();
            $app->enqueueMessage('Campground pricing saved.');
        }catch(\Throwable $e){
            try{$db->transactionRollback();}catch(\Throwable $ignore){}
            $app->enqueueMessage('Could not save pricing: '.$e->getMessage(),'error');
        }
        $this->setRedirect(Route::_('index.php?option=com_rvreservations#pricing',false));
    }
}
