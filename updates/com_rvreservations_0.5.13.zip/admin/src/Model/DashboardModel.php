<?php
namespace LADistrict\Component\Rvreservations\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

class DashboardModel extends BaseDatabaseModel
{
    public function getSites(): array
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true)
            ->select('s.*')
            ->from($db->quoteName('#__rv_sites', 's'))
            ->order("FIELD(s.site_status,'active','inactive','map_only') ASC, " . $db->quoteName('s.ordering') . ' ASC, ' . $db->quoteName('s.site_number') . ' ASC');
        $db->setQuery($query);
        return $db->loadAssocList() ?: [];
    }

    public function getEditSite(): array
    {
        $id = Factory::getApplication()->getInput()->getInt('edit_id');
        if (!$id) return [];
        $db = $this->getDatabase();
        $query = $db->getQuery(true)->select('*')->from($db->quoteName('#__rv_sites'))->where($db->quoteName('id') . ' = ' . (int) $id);
        $db->setQuery($query);
        return $db->loadAssoc() ?: [];
    }


    public function getReservations(): array
    {
        $db=$this->getDatabase();
        $q=$db->getQuery(true)
          ->select('r.*, s.site_number')
          ->from($db->quoteName('#__rv_reservations','r'))
          ->join('LEFT',$db->quoteName('#__rv_reservation_sites','rs').' ON rs.reservation_id=r.id')
          ->join('LEFT',$db->quoteName('#__rv_sites','s').' ON s.id=rs.site_id')
          ->order('r.created DESC');
        $db->setQuery($q,0,100);
        return $db->loadAssocList() ?: [];
    }

    public function getEditReservation(): array
    {
        $id=Factory::getApplication()->getInput()->getInt('edit_reservation');
        if(!$id)return [];
        $db=$this->getDatabase();
        $q=$db->getQuery(true)
          ->select('r.*, rs.site_id')
          ->from($db->quoteName('#__rv_reservations','r'))
          ->join('LEFT',$db->quoteName('#__rv_reservation_sites','rs').' ON rs.reservation_id=r.id')
          ->where('r.id='.(int)$id);
        $db->setQuery($q);
        $row=$db->loadAssoc() ?: [];
        if($row){
            $q=$db->getQuery(true)->select('date_from, date_to, usage_mode')->from($db->quoteName('#__rv_reservation_periods'))
              ->where('reservation_id='.(int)$id)->order('date_from ASC');
            $db->setQuery($q); $periods=$db->loadAssocList() ?: []; $occupied=[];
            foreach($periods as $period){
                if(($period['usage_mode'] ?? '')!=='occupied') continue;
                $n=new \DateTimeImmutable($period['date_from']); $end=new \DateTimeImmutable($period['date_to']);
                while($n<$end){$occupied[]=$n->format('Y-m-d');$n=$n->modify('+1 day');}
            }
            if(!$periods && ($row['usage_mode'] ?? '')==='occupied'){
                $n=new \DateTimeImmutable($row['arrival']); $end=new \DateTimeImmutable($row['departure']);
                while($n<$end){$occupied[]=$n->format('Y-m-d');$n=$n->modify('+1 day');}
            }
            $row['occupied_nights']=array_values(array_unique($occupied));
        }
        return $row;
    }


    public function getRates(): array
    {
        $db=$this->getDatabase();
        $q=$db->getQuery(true)
            ->select('*')
            ->from($db->quoteName('#__rv_rates'))
            ->where('site_id IS NULL')
            ->where('site_type_id IS NULL')
            ->where('state=1')
            ->order('date_from DESC, usage_mode ASC');
        $db->setQuery($q);
        return $db->loadAssocList() ?: [];
    }

    public function getStats(): array
    {
        $db = $this->getDatabase();
        $db->setQuery("SELECT COUNT(*) total, SUM(site_status='active') active, SUM(site_status='inactive') inactive, SUM(site_status='map_only') map_only, SUM(handicap=1) handicap FROM " . $db->quoteName('#__rv_sites'));
        $row = $db->loadAssoc() ?: [];
        
        $db->setQuery('SELECT COUNT(*) FROM ' . $db->quoteName('#__rv_sites') . ' WHERE map_x IS NOT NULL AND map_y IS NOT NULL');
        $mapped=(int)$db->loadResult();
        $db->setQuery('SELECT COUNT(*) FROM ' . $db->quoteName('#__rv_sites') . ' WHERE map_region = ' . $db->quote('west') . ' AND map_x IS NOT NULL AND map_y IS NOT NULL');
        $mappedWest=(int)$db->loadResult();
        $db->setQuery('SELECT COUNT(*) FROM ' . $db->quoteName('#__rv_sites') . ' WHERE map_region = ' . $db->quote('east') . ' AND map_x IS NOT NULL AND map_y IS NOT NULL');
        $mappedEast=(int)$db->loadResult();
        $unmapped=max(0,(int)($row['total']??0)-$mapped);
        return ['total'=>(int)($row['total']??0),'active'=>(int)($row['active']??0),'inactive'=>(int)($row['inactive']??0),'map_only'=>(int)($row['map_only']??0),'handicap'=>(int)($row['handicap']??0),'mapped'=>$mapped,'mapped_west'=>$mappedWest,'mapped_east'=>$mappedEast,'unmapped'=>$unmapped];
    }
}
