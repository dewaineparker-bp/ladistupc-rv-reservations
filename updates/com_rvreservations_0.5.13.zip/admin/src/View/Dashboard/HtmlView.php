<?php
namespace LADistrict\Component\Rvreservations\Administrator\View\Dashboard;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Factory;

class HtmlView extends BaseHtmlView
{
    public array $sites = [];
    public array $editSite = [];
    public array $stats = [];
    public array $reservations = [];
    public array $editReservation = [];
    public array $rates = [];

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $this->sites = $model->getSites();
        $this->editSite = $model->getEditSite();
        $this->stats = $model->getStats();
        $this->reservations = $model->getReservations();
        $this->editReservation = $model->getEditReservation();
        $this->rates = $model->getRates();
        Factory::getApplication()->getDocument()->getWebAssetManager()
            ->registerAndUseStyle('com_rvreservations.admin', 'com_rvreservations/css/admin.css');
        parent::display($tpl);
    }
}
