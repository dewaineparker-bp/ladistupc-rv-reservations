<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$sites = $this->sites;
$edit = $this->editSite;
$stats = $this->stats;
$reservations = $this->reservations;
$editReservation = $this->editReservation;
$rates = $this->rates;
$e = array_merge([
 'id'=>0,'site_number'=>'','title'=>'','location'=>'','rv_classes'=>'','amp_service'=>'','lot_width'=>'','lot_length'=>'','max_slideouts'=>'','foundation'=>'','shade_level'=>'','handicap'=>0,'notes'=>'','description'=>'','site_status'=>'active','state'=>1,'ordering'=>0
], $edit);
?>
<div class="container-fluid">
  <div class="d-flex justify-content-between align-items-start flex-wrap gap-3 mb-4">
    <div><h1 class="h2 mb-1">RV Reservations</h1><p class="text-muted mb-0">Version 0.5.11 — physical-site status and map inventory support.</p></div>
    <a class="btn btn-outline-primary" href="../index.php?option=com_rvreservations" target="_blank" rel="noopener">Open public availability screen</a>
  </div>

  <div class="row g-3 mb-4">
    <div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Sites</div><div class="display-6"><?= (int)$stats['total'] ?></div></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Reservable</div><div class="display-6"><?= (int)$stats['active'] ?></div><div class="small text-muted"><?= (int)($stats['inactive']??0) ?> inactive · <?= (int)($stats['map_only']??0) ?> map only</div></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Handicap</div><div class="display-6"><?= (int)$stats['handicap'] ?></div></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Mapped Sites</div><div class="display-6"><?= (int)($stats['mapped'] ?? 0) ?></div></div></div></div>
  </div>


  <div class="card mb-4" id="pricing">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
        <div><h2 class="h4 mb-1">Campground Pricing</h2><p class="text-muted mb-0">One occupied nightly rate and one stored nightly rate apply to every RV site. New rates can start on a future effective date without changing older reservations.</p></div>
      </div>
      <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=rate.save') ?>" class="row g-3 align-items-end mb-4">
        <div class="col-md-3"><label class="form-label">Effective date</label><input class="form-control" type="date" name="effective_date" required value="<?= date('Y-m-d') ?>"></div>
        <div class="col-md-3"><label class="form-label">Occupied nightly rate</label><div class="input-group"><span class="input-group-text">$</span><input class="form-control" type="number" step="0.01" min="0" name="occupied_rate" required></div></div>
        <div class="col-md-3"><label class="form-label">Stored nightly rate</label><div class="input-group"><span class="input-group-text">$</span><input class="form-control" type="number" step="0.01" min="0" name="storage_rate" required></div></div>
        <div class="col-md-3"><button class="btn btn-primary" type="submit">Save New Rates</button></div>
        <?= HTMLHelper::_('form.token') ?>
      </form>
      <?php if(!$rates): ?>
        <div class="alert alert-warning mb-0">No pricing has been configured yet. Public reservations will calculate at $0 until rates are entered.</div>
      <?php else: ?>
        <div class="table-responsive"><table class="table table-sm align-middle mb-0"><thead><tr><th>Effective</th><th>Through</th><th>Use</th><th>Nightly rate</th></tr></thead><tbody>
        <?php foreach($rates as $rate): ?><tr><td><?= htmlspecialchars($rate['date_from']) ?></td><td><?= $rate['date_to']==='9999-12-31'?'Current':htmlspecialchars($rate['date_to']) ?></td><td><?= ucfirst(htmlspecialchars($rate['usage_mode'])) ?></td><td>$<?= number_format((float)$rate['daily_rate'],2) ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mb-4 rv-map-audit">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div><h2 class="h4 mb-1">Map Audit</h2><p class="text-muted mb-0">The public map and this editor now use the same rendering script and the same database coordinates.</p></div>
        <span class="badge <?= (int)($stats['unmapped'] ?? 0) === 0 ? 'bg-success' : 'bg-warning text-dark' ?> fs-6"><?= (int)($stats['mapped'] ?? 0) ?> / <?= (int)$stats['total'] ?> mapped</span>
      </div>
      <div class="rv-map-audit-grid">
        <div><span>West mapped</span><strong><?= (int)($stats['mapped_west'] ?? 0) ?></strong></div>
        <div><span>East mapped</span><strong><?= (int)($stats['mapped_east'] ?? 0) ?></strong></div>
        <div><span>Unmapped</span><strong><?= (int)($stats['unmapped'] ?? 0) ?></strong></div>
        <div><span>Total inventory</span><strong><?= (int)$stats['total'] ?></strong></div>
      </div>
      <?php if((int)($stats['unmapped'] ?? 0) > 0): ?>
        <div class="alert alert-warning mt-3 mb-0">There are <?= (int)$stats['unmapped'] ?> sites without map coordinates. They remain in the site inventory but will not be clickable publicly until mapped.</div>
      <?php else: ?>
        <div class="alert alert-success mt-3 mb-0">All <?= (int)$stats['total'] ?> sites have East/West map coordinates.</div>
      <?php endif; ?>
    </div>
  </div>

  <div class="card mb-4" id="reservations">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <div><h2 class="h4 mb-1">Reservations</h2><p class="text-muted mb-0">Open a reservation to change its dates, site, occupied/storage mode, or status.</p></div>
        <span class="badge bg-secondary"><?= count($reservations) ?> recent</span>
      </div>

      <?php if($editReservation):
        $er=array_merge(['id'=>0,'site_id'=>0,'arrival'=>'','departure'=>'','usage_mode'=>'occupied','occupied_nights'=>[],'status'=>'pending','customer_name'=>'','confirmation_code'=>''], $editReservation);
      ?>
      <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=reservation.save') ?>" class="border rounded p-3 mb-4 bg-light">
        <input type="hidden" name="id" value="<?= (int)$er['id'] ?>">
        <div class="d-flex justify-content-between gap-2 flex-wrap mb-3"><div><strong>Edit <?= htmlspecialchars($er['confirmation_code'] ?: '#'.$er['id']) ?></strong><div class="text-muted"><?= htmlspecialchars($er['customer_name']) ?></div></div><a href="<?= Route::_('index.php?option=com_rvreservations#reservations') ?>" class="btn btn-sm btn-outline-secondary">Close editor</a></div>
        <div class="row g-3">
          <div class="col-md-3"><label class="form-label">Arrival</label><input class="form-control" type="date" name="arrival" required value="<?= htmlspecialchars($er['arrival']) ?>"></div>
          <div class="col-md-3"><label class="form-label">Departure</label><input class="form-control" type="date" name="departure" required value="<?= htmlspecialchars($er['departure']) ?>"></div>

          <div class="col-md-2"><label class="form-label">Site</label><select class="form-select" name="site_id" required><?php foreach($sites as $rs): ?><option value="<?= (int)$rs['id'] ?>" <?= (int)$er['site_id']===(int)$rs['id']?'selected':'' ?>><?= htmlspecialchars($rs['site_number']) ?></option><?php endforeach; ?></select></div>
          <div class="col-md-2"><label class="form-label">Status</label><select class="form-select" name="status"><option value="pending" <?= $er['status']==='pending'?'selected':'' ?>>Pending</option><option value="confirmed" <?= $er['status']==='confirmed'?'selected':'' ?>>Confirmed</option><option value="cancelled" <?= $er['status']==='cancelled'?'selected':'' ?>>Cancelled</option></select></div>
        </div>
        <div class="rv-admin-night-editor mt-3" data-admin-night-editor data-occupied='<?= htmlspecialchars(json_encode(array_values($er['occupied_nights'] ?? [])), ENT_QUOTES, 'UTF-8') ?>'>
          <label class="form-label fw-bold">Occupied nights</label>
          <p class="text-muted mb-2">Check the nights the RV will be occupied. Unchecked nights are storage.</p>
          <div class="rv-admin-night-grid"></div>
        </div>
        <?= HTMLHelper::_('form.token') ?>
        <button class="btn btn-primary mt-3" type="submit">Save Reservation Changes</button>
      </form>
      <?php endif; ?>

      <?php if(!$reservations): ?><div class="alert alert-info mb-0">No reservations have been created in the new system yet.</div>
      <?php else: ?><div class="table-responsive"><table class="table table-hover align-middle">
        <thead><tr><th>Confirmation</th><th>Customer</th><th>Site</th><th>Dates</th><th>Use</th><th>Status</th><th></th></tr></thead>
        <tbody><?php foreach($reservations as $r): ?><tr>
          <td><strong><?= htmlspecialchars((string)$r['confirmation_code']) ?></strong></td>
          <td><?= htmlspecialchars((string)$r['customer_name']) ?><div class="small text-muted"><?= htmlspecialchars((string)$r['customer_email']) ?></div></td>
          <td><?= htmlspecialchars((string)$r['site_number']) ?></td>
          <td><?= htmlspecialchars((string)$r['arrival']) ?> → <?= htmlspecialchars((string)$r['departure']) ?></td>
          <td><?= $r['usage_mode']==='storage'?'Storage':($r['usage_mode']==='mixed'?'Mixed':'Occupied') ?></td>
          <td><span class="badge <?= $r['status']==='confirmed'?'bg-success':($r['status']==='cancelled'?'bg-secondary':'bg-warning text-dark') ?>"><?= htmlspecialchars(ucfirst((string)$r['status'])) ?></span></td>
          <td><a class="btn btn-sm btn-outline-primary" href="<?= Route::_('index.php?option=com_rvreservations&edit_reservation='.(int)$r['id'].'#reservations') ?>">Edit</a></td>
        </tr><?php endforeach; ?></tbody>
      </table></div><?php endif; ?>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-body">
      <h2 class="h4">Import existing RV sites</h2>
      <p>This package contains a site-only snapshot extracted from the Solidres SQL dump you supplied. It imports active RV sites only, ignores cabins/houses, and collapses duplicate Solidres site labels.</p>
      <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=site.importSnapshot') ?>">
        <?= HTMLHelper::_('form.token') ?>
        <button class="btn btn-success" type="submit">Import Solidres RV Sites</button>
      </form>
    </div>
  </div>

  <div class="card mb-4" id="map-editor"><div class="card-body rv-admin-map-shell">
    <style>
      .rv58-map-tools{display:grid;grid-template-columns:minmax(220px,1.4fr) 1fr 1fr auto;gap:12px;align-items:end;margin:12px 0}
      .rv58-map-tools label,.rv58-rotation label{font-weight:700;display:block;margin-bottom:5px}
      .rv58-rotation{display:grid;grid-template-columns:auto auto minmax(220px,1fr) auto;gap:10px;align-items:center;margin:8px 0 12px}
      .rv58-viewbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:10px 0}
      .rv58-viewport{position:relative;width:100%;overflow:auto;max-height:76vh;border:1px solid #aeb6bf;background:#dfe3e6}
      .rv58-stage{position:relative;width:100%;min-width:100%;transform-origin:top left;background:#fff}
      .rv58-stage>img{display:block;width:100%;height:auto;user-select:none;-webkit-user-drag:none}
      .rv58-saved{position:absolute;box-sizing:border-box;border:1px solid rgba(13,110,253,.65);background:rgba(13,110,253,.10);pointer-events:none;display:none;transform-origin:center center}
      .rv58-show-all .rv58-saved{display:block}
      .rv58-current{position:absolute;box-sizing:border-box;border:2px solid #d63384;background:rgba(214,51,132,.26);box-shadow:0 0 0 1px #fff;z-index:50;cursor:move;transform-origin:center center;min-width:1px;min-height:1px}
      .rv58-current[hidden]{display:none!important}
      .rv58-handle{position:absolute;width:9px;height:9px;right:-5px;bottom:-5px;background:#d63384;border:1px solid #fff;border-radius:2px;cursor:nwse-resize}
      .rv58-viewport.is-expanded{position:fixed;inset:8px;z-index:100000;max-height:none;background:#20252a;border:2px solid #fff;border-radius:10px;padding:8px;box-shadow:0 20px 80px rgba(0,0,0,.55)}
      .rv58-viewport.is-expanded .rv58-stage{background:#fff}.rv58-body-lock{overflow:hidden}
      .rv58-site-note{font-weight:700;color:#344054;margin-left:auto}
      @media(max-width:900px){.rv58-map-tools{grid-template-columns:1fr}.rv58-rotation{grid-template-columns:1fr auto auto}.rv58-rotation input{grid-column:1/-1}.rv58-site-note{margin-left:0;flex-basis:100%}}
    </style>
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-2">
      <div><h2 class="h4 mb-1">Campground Map Editor</h2><p class="text-muted mb-0">Choose a side and a site. The pink box is the only box you edit. Click the map to place it, drag it to move, use the corner handle to resize, and rotate as needed.</p></div>
      <span class="badge bg-primary fs-6"><?= (int)($stats['mapped'] ?? 0) ?> mapped</span>
    </div>
    <?php
      $mapArea=in_array(($_GET['map_area'] ?? 'west'),['west','east'],true)?$_GET['map_area']:'west';
      $selectedMap=(int)($_GET['map_site'] ?? 0);
      $areaSites=array_values(array_filter($sites,fn($s)=>(($s['map_region'] ?? '')===$mapArea || empty($s['map_region']))));
    ?>
    <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=site.saveMap') ?>" id="rv58-map-form">
      <div class="mb-2 d-flex gap-2 flex-wrap">
        <a class="btn <?= $mapArea==='west'?'btn-primary':'btn-outline-primary' ?>" href="<?= Route::_('index.php?option=com_rvreservations&map_area=west#map-editor') ?>">West Campground</a>
        <a class="btn <?= $mapArea==='east'?'btn-primary':'btn-outline-primary' ?>" href="<?= Route::_('index.php?option=com_rvreservations&map_area=east#map-editor') ?>">East Campground</a>
      </div>
      <input type="hidden" name="map_region" value="<?= htmlspecialchars($mapArea) ?>">
      <div class="rv58-map-tools">
        <div><label for="rv58-site">Site</label><select class="form-select" name="site_id" id="rv58-site" required><option value="">Choose a site…</option><?php foreach($areaSites as $ms): ?><option value="<?= (int)$ms['id'] ?>" data-x="<?= $ms['map_x']!==null?(float)$ms['map_x']:'' ?>" data-y="<?= $ms['map_y']!==null?(float)$ms['map_y']:'' ?>" data-w="<?= $ms['map_w']!==null?(float)$ms['map_w']:'' ?>" data-h="<?= $ms['map_h']!==null?(float)$ms['map_h']:'' ?>" data-r="<?= (float)($ms['map_rotation'] ?? 0) ?>" <?= $selectedMap===(int)$ms['id']?'selected':'' ?>><?= htmlspecialchars($ms['site_number']) ?><?= $ms['map_x']!==null?' ✓':'' ?></option><?php endforeach; ?></select></div>
        <div><label for="rv58-w-slider">Box width</label><input id="rv58-w-slider" class="form-range" type="range" min="0.05" max="12" step="0.05" value="1.5"></div>
        <div><label for="rv58-h-slider">Box height</label><input id="rv58-h-slider" class="form-range" type="range" min="0.05" max="12" step="0.05" value="1.5"></div>
        <div><button class="btn btn-primary" type="submit">Save Position</button></div>
      </div>
      <div class="rv58-rotation">
        <label for="rv58-r-slider">Rotation <strong id="rv58-r-label">0°</strong></label>
        <button type="button" class="btn btn-sm btn-outline-secondary" id="rv58-left">↶ 5°</button>
        <input id="rv58-r-slider" type="range" min="-180" max="180" step="1" value="0">
        <button type="button" class="btn btn-sm btn-outline-secondary" id="rv58-right">↷ 5°</button>
      </div>
      <div class="rv58-viewbar">
        <button type="button" class="btn btn-outline-primary" id="rv58-expand">Expand Map</button>
        <div class="btn-group"><button type="button" class="btn btn-outline-secondary" id="rv58-zout">−</button><button type="button" class="btn btn-outline-secondary disabled" id="rv58-zlabel">100%</button><button type="button" class="btn btn-outline-secondary" id="rv58-zin">+</button><button type="button" class="btn btn-outline-secondary" id="rv58-reset">Reset</button></div>
        <label class="form-check ms-2"><input class="form-check-input" type="checkbox" id="rv58-show-all"> <span class="form-check-label">Show all mapped sites</span></label>
        <strong class="rv58-site-note" id="rv58-editing">Choose a site to edit</strong>
      </div>
      <input type="hidden" name="map_x" id="rv58-x"><input type="hidden" name="map_y" id="rv58-y"><input type="hidden" name="map_w" id="rv58-w"><input type="hidden" name="map_h" id="rv58-h"><input type="hidden" name="map_rotation" id="rv58-r">
      <?= HTMLHelper::_('form.token') ?>
      <div class="rv58-viewport" id="rv58-viewport">
        <div class="rv58-stage" id="rv58-stage">
          <img src="<?= htmlspecialchars(rtrim(Uri::root(), '/')) ?>/media/com_rvreservations/images/campground-map-<?= $mapArea ?>.jpg" alt="<?= ucfirst($mapArea) ?> campground map">
          <?php foreach($areaSites as $ms): if($ms['map_x']===null||$ms['map_y']===null) continue; ?>
            <div class="rv58-saved" style="left:<?= (float)$ms['map_x'] ?>%;top:<?= (float)$ms['map_y'] ?>%;width:<?= (float)($ms['map_w']?:1.5) ?>%;height:<?= (float)($ms['map_h']?:1.5) ?>%;transform:rotate(<?= (float)($ms['map_rotation']??0) ?>deg)" title="Site <?= htmlspecialchars((string)$ms['site_number'],ENT_QUOTES,'UTF-8') ?>"></div>
          <?php endforeach; ?>
          <div class="rv58-current" id="rv58-current" hidden><i class="rv58-handle" id="rv58-handle"></i></div>
        </div>
      </div>
    </form>
    <p class="text-muted mt-2 mb-0">Tip: leave “Show all mapped sites” off while editing tight areas. The pink box is always the selected site.</p>
  </div></div>

  <div class="card mb-4" id="site-editor"><div class="card-body">
    <h2 class="h4"><?= $e['id'] ? 'Edit Site '.htmlspecialchars($e['site_number']) : 'Add RV Site' ?></h2>
    <form method="post" action="<?= Route::_('index.php?option=com_rvreservations&task=site.save') ?>">
      <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
      <div class="row g-3">
        <div class="col-md-2"><label class="form-label">Site #</label><input class="form-control" name="site_number" required value="<?= htmlspecialchars((string)$e['site_number']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Title</label><input class="form-control" name="title" value="<?= htmlspecialchars((string)$e['title']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Location</label><input class="form-control" name="location" value="<?= htmlspecialchars((string)$e['location']) ?>"></div>
        <div class="col-md-2"><label class="form-label">AMP</label><input class="form-control" name="amp_service" placeholder="30, 50, 30/50" value="<?= htmlspecialchars((string)$e['amp_service']) ?>"></div>
        <div class="col-md-4"><label class="form-label">Allowed RV Classes</label><input class="form-control" name="rv_classes" value="<?= htmlspecialchars((string)$e['rv_classes']) ?>"></div>
        <div class="col-md-2"><label class="form-label">Lot width (ft)</label><input class="form-control" type="number" name="lot_width" value="<?= htmlspecialchars((string)$e['lot_width']) ?>"></div>
        <div class="col-md-2"><label class="form-label">Lot length (ft)</label><input class="form-control" type="number" name="lot_length" value="<?= htmlspecialchars((string)$e['lot_length']) ?>"></div><div class="col-md-2"><label class="form-label">Max slide-outs</label><input class="form-control" type="number" min="0" name="max_slideouts" placeholder="No limit" value="<?= htmlspecialchars((string)$e['max_slideouts']) ?>"><div class="form-text">Leave blank when there is no numeric restriction.</div></div>
        <div class="col-md-2"><label class="form-label">Foundation</label><input class="form-control" name="foundation" value="<?= htmlspecialchars((string)$e['foundation']) ?>"></div>
        <div class="col-md-2"><label class="form-label">Shade</label><input class="form-control" name="shade_level" value="<?= htmlspecialchars((string)$e['shade_level']) ?>"></div>
        <div class="col-md-2"><label class="form-label">Ordering</label><input class="form-control" type="number" name="ordering" value="<?= (int)$e['ordering'] ?>"></div>
        <div class="col-md-2"><label class="form-label">Site status</label><select class="form-select" name="site_status"><option value="active" <?= $e['site_status']==='active'?'selected':'' ?>>Active / Reservable</option><option value="inactive" <?= $e['site_status']==='inactive'?'selected':'' ?>>Inactive</option><option value="map_only" <?= $e['site_status']==='map_only'?'selected':'' ?>>Map Only</option></select><div class="form-text">Inactive and Map Only sites stay visible on the map but can never be reserved.</div><div class="form-check mt-2"><input class="form-check-input" type="checkbox" name="handicap" value="1" id="handicap" <?= $e['handicap']?'checked':'' ?>><label class="form-check-label" for="handicap">Handicap site</label></div></div>
        <div class="col-md-5"><label class="form-label">Notes</label><textarea class="form-control" name="notes" rows="2"><?= htmlspecialchars((string)$e['notes']) ?></textarea></div>
        <div class="col-md-5"><label class="form-label">Description</label><textarea class="form-control" name="description" rows="2"><?= htmlspecialchars((string)$e['description']) ?></textarea></div>
      </div>
      <?= HTMLHelper::_('form.token') ?>
      <div class="mt-3"><button class="btn btn-primary" type="submit">Save Site</button><?php if($e['id']): ?> <a class="btn btn-secondary" href="<?= Route::_('index.php?option=com_rvreservations') ?>">Cancel</a><?php endif; ?></div>
    </form>
  </div></div>

  <div class="card"><div class="card-body">
    <h2 class="h4">RV Sites</h2>
    <?php if(!$sites): ?><p class="text-muted">No sites loaded yet. Use the Solidres import above.</p><?php else: ?>
    <div class="table-responsive"><table class="table table-striped table-hover align-middle">
      <thead><tr><th>Site</th><th>Location</th><th>AMP</th><th>Lot</th><th>RV type</th><th>Status</th><th></th></tr></thead>
      <tbody><?php foreach($sites as $s): ?>
        <tr>
          <td><strong><?= htmlspecialchars($s['site_number']) ?></strong><?= $s['handicap']?' <span class="badge bg-info">Handicap</span>':'' ?></td>
          <td><?= htmlspecialchars((string)$s['location']) ?></td>
          <td><?= htmlspecialchars((string)$s['amp_service']) ?></td>
          <td><?= $s['lot_width']&&$s['lot_length'] ? (int)$s['lot_width'].' × '.(int)$s['lot_length'].' ft' : '—' ?></td>
          <td><small><?= htmlspecialchars((string)$s['rv_classes']) ?></small></td>
          <td><?php $ss=$s['site_status']??($s['state']?'active':'inactive'); if($ss==='active'): ?><span class="badge bg-success">Active</span><?php elseif($ss==='map_only'): ?><span class="badge bg-info text-dark">Map Only</span><?php else: ?><span class="badge bg-secondary">Inactive</span><?php endif; ?></td>
          <td class="text-nowrap"><a class="btn btn-sm btn-outline-primary" href="<?= Route::_('index.php?option=com_rvreservations&edit_id='.(int)$s['id'].'#site-editor') ?>">Edit</a></td>
        </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div></div>
</div>

<script>
document.addEventListener('DOMContentLoaded',function(){
  var stage=document.getElementById('rv58-stage'); if(!stage)return;
  var select=document.getElementById('rv58-site'), box=document.getElementById('rv58-current'), handle=document.getElementById('rv58-handle');
  var x=document.getElementById('rv58-x'),y=document.getElementById('rv58-y'),w=document.getElementById('rv58-w'),h=document.getElementById('rv58-h'),r=document.getElementById('rv58-r');
  var ws=document.getElementById('rv58-w-slider'),hs=document.getElementById('rv58-h-slider'),rs=document.getElementById('rv58-r-slider'),rlabel=document.getElementById('rv58-r-label'),editing=document.getElementById('rv58-editing');
  var viewport=document.getElementById('rv58-viewport'),showAll=document.getElementById('rv58-show-all');
  var zooms=[100,125,150,175,200,250,300,350,400],zi=0,mode=null,start=null;
  function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
  function num(el,d){var n=parseFloat(el.value);return isFinite(n)?n:d;}
  function vals(){return {x:num(x,45),y:num(y,45),w:num(w,1.5),h:num(h,1.5),r:num(r,0)};}
  function render(){var v=vals();box.style.left=v.x+'%';box.style.top=v.y+'%';box.style.width=v.w+'%';box.style.height=v.h+'%';box.style.transform='rotate('+v.r+'deg)';box.hidden=!select.value;ws.value=v.w;hs.value=v.h;rs.value=v.r;rlabel.textContent=Math.round(v.r)+'°';var o=select.options[select.selectedIndex];editing.textContent=select.value?'Editing site '+o.text.replace(' ✓',''):'Choose a site to edit';}
  function load(){var o=select.options[select.selectedIndex];if(!select.value){box.hidden=true;editing.textContent='Choose a site to edit';return;}x.value=o.dataset.x!==''?o.dataset.x:45;y.value=o.dataset.y!==''?o.dataset.y:45;w.value=o.dataset.w!==''?o.dataset.w:1.5;h.value=o.dataset.h!==''?o.dataset.h:1.5;r.value=o.dataset.r!==''?o.dataset.r:0;render();}
  function point(e){var q=stage.getBoundingClientRect();return{x:(e.clientX-q.left)/q.width*100,y:(e.clientY-q.top)/q.height*100};}
  select.addEventListener('change',load);
  stage.addEventListener('click',function(e){if(!select.value||e.target===box||box.contains(e.target))return;var p=point(e),v=vals();x.value=clamp(p.x-v.w/2,0,100-v.w).toFixed(4);y.value=clamp(p.y-v.h/2,0,100-v.h).toFixed(4);render();});
  box.addEventListener('pointerdown',function(e){if(!select.value)return;e.preventDefault();e.stopPropagation();mode=e.target===handle?'resize':'move';start={p:point(e),v:vals()};try{box.setPointerCapture(e.pointerId);}catch(_){} });
  box.addEventListener('pointermove',function(e){if(!mode||!start)return;var p=point(e),dx=p.x-start.p.x,dy=p.y-start.p.y;if(mode==='move'){x.value=clamp(start.v.x+dx,0,100-start.v.w).toFixed(4);y.value=clamp(start.v.y+dy,0,100-start.v.h).toFixed(4);}else{w.value=clamp(start.v.w+dx,.05,100-start.v.x).toFixed(4);h.value=clamp(start.v.h+dy,.05,100-start.v.y).toFixed(4);}render();});
  ['pointerup','pointercancel'].forEach(function(n){box.addEventListener(n,function(){mode=null;start=null;});});
  ws.addEventListener('input',function(){w.value=ws.value;render();});hs.addEventListener('input',function(){h.value=hs.value;render();});rs.addEventListener('input',function(){r.value=rs.value;render();});
  document.getElementById('rv58-left').addEventListener('click',function(){r.value=clamp(num(r,0)-5,-180,180);render();});document.getElementById('rv58-right').addEventListener('click',function(){r.value=clamp(num(r,0)+5,-180,180);render();});
  function zoom(i){zi=clamp(i,0,zooms.length-1);var z=zooms[zi];stage.style.width=z+'%';stage.style.minWidth=z+'%';document.getElementById('rv58-zlabel').textContent=z+'%';}
  document.getElementById('rv58-zin').addEventListener('click',function(){zoom(zi+1);});document.getElementById('rv58-zout').addEventListener('click',function(){zoom(zi-1);});document.getElementById('rv58-reset').addEventListener('click',function(){zoom(0);viewport.scrollTop=0;viewport.scrollLeft=0;});
  document.getElementById('rv58-expand').addEventListener('click',function(){var on=viewport.classList.toggle('is-expanded');document.body.classList.toggle('rv58-body-lock',on);this.textContent=on?'Close Expanded Map':'Expand Map';if(on&&zi<2)zoom(2);});
  showAll.addEventListener('change',function(){stage.classList.toggle('rv58-show-all',showAll.checked);});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&viewport.classList.contains('is-expanded')){viewport.classList.remove('is-expanded');document.body.classList.remove('rv58-body-lock');document.getElementById('rv58-expand').textContent='Expand Map';}});
  zoom(0);load();
});
</script>

<script>
document.addEventListener('DOMContentLoaded',()=>{
 const ed=document.querySelector('[data-admin-night-editor]'); if(!ed)return;
 const a=document.querySelector('input[name="arrival"]'), d=document.querySelector('input[name="departure"]'), grid=ed.querySelector('.rv-admin-night-grid');
 const initially=new Set(JSON.parse(ed.dataset.occupied||'[]')); let first=true;
 function render(){
  if(!a.value||!d.value){grid.innerHTML='';return;} const start=new Date(a.value+'T12:00:00'), end=new Date(d.value+'T12:00:00'); if(!(end>start)){grid.innerHTML='<span class="text-danger">Departure must be after arrival.</span>';return;}
  const checkedNow=new Set([...grid.querySelectorAll('input:checked')].map(x=>x.value)); const selected=first?initially:checkedNow; first=false; grid.innerHTML='';
  for(let n=new Date(start);n<end;n.setDate(n.getDate()+1)){const v=n.toISOString().slice(0,10), label=n.toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'}); const el=document.createElement('label'); el.className='rv-admin-night-option'; el.innerHTML=`<input type="checkbox" name="occupied_nights[]" value="${v}" ${selected.has(v)?'checked':''}><span>${label}</span>`; grid.appendChild(el);}
 }
 a.addEventListener('change',render);d.addEventListener('change',render);render();
});
</script>
